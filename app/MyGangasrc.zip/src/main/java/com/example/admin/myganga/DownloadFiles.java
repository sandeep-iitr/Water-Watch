package com.example.admin.myganga;

import android.os.AsyncTask;
import android.util.Log;

import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.URL;

/**
 * Created by admin on 8/18/2015.
 */

public class DownloadFiles extends AsyncTask<URL, Integer, Long> {
    protected Long doInBackground(URL... urls) {
        //  int count = urls.length;
        long totalSize = 0;
        DefaultHttpClient httpclient = new DefaultHttpClient();
        HttpPost httppostreq = new HttpPost("http://cdata.mybluemix.net/Send_places");
           /* StringEntity se = new StringEntity(jsonobj.toString());
            se.setContentType("application/json;charset=UTF-8");
            se.setContentEncoding(new BasicHeader(HTTP.CONTENT_TYPE, "application/json;charset=UTF-8"));
            httppostreq.setEntity(se);
            */
        try {
            HttpResponse httpresponse = httpclient.execute(httppostreq);

            InputStream stream=httpresponse.getEntity().getContent();
            BufferedReader reader = new BufferedReader(new InputStreamReader(
                    stream, "UTF-8"), 8);
            StringBuilder sb = new StringBuilder();
            String line = null;
            while ((line = reader.readLine()) != null) {
                sb.append(line + "\n");
            }
            String response = sb.toString();
            stream.close();
            //
            //Toast.makeText(cnt, stream.toString(), Toast.LENGTH_SHORT).show();
            Log.d("cloud server", "stream from server" + response);

            //places are in response string
            try {
                JSONArray jsonArray = new JSONArray(response);


                //clearing already read places in the memory
                if(GlobalData.numPlaces>0)
                {
                    GlobalData.numPlaces=0;
                    GlobalData.place.clear();
                }


                for (int i = 0; i < jsonArray.length(); i++) {
                    JSONObject jo_inside = jsonArray.getJSONObject(i);
                    Log.d("Details-->", jo_inside.getString("Place_name"));
                    Places p1=new Places();
                    p1.Place_id=jo_inside.getInt("Place_id");
                    p1.Lat=jo_inside.getString("Lat");;
                    p1.Lng=jo_inside.getString("Lng");
                    p1.Place_name=jo_inside.getString("Place_name");
                    GlobalData.place.add(p1);
                    GlobalData.numPlaces++;
                }

            } catch (JSONException e) {
                e.printStackTrace();
            }


        } catch (IOException e) {
            e.printStackTrace();
        }


        //////////////////////////////////////////////////////////////
        // loading data of places read earlier

        httppostreq = new HttpPost("http://cdata.mybluemix.net/Send_places_data");
           /* StringEntity se = new StringEntity(jsonobj.toString());
            se.setContentType("application/json;charset=UTF-8");
            se.setContentEncoding(new BasicHeader(HTTP.CONTENT_TYPE, "application/json;charset=UTF-8"));
            httppostreq.setEntity(se);
            */
        try {
            HttpResponse httpresponse = httpclient.execute(httppostreq);

            InputStream stream=httpresponse.getEntity().getContent();
            BufferedReader reader = new BufferedReader(new InputStreamReader(
                    stream, "UTF-8"), 8);
            StringBuilder sb = new StringBuilder();
            String line = null;
            while ((line = reader.readLine()) != null) {
                sb.append(line + "\n");
            }
            String response2 = sb.toString();
            stream.close();
            //
            //Toast.makeText(cnt, stream.toString(), Toast.LENGTH_SHORT).show();
            Log.d("cloud server","stream from server"+ response2);

            //places are in response string
            try {
                JSONArray jsonArray = new JSONArray(response2);


                //clearing already read places in the memory
                if(GlobalData.Datapoint>0)
                {
                    GlobalData.Datapoint=0;
                    GlobalData.sensordata.clear();
                }


                for (int i = 0; i < jsonArray.length(); i++) {
                    JSONObject jo_inside = jsonArray.getJSONObject(i);
                    if(jo_inside.has("Place_name"))
                    Log.d("Details-data->", jo_inside.getString("Place_name"));
                    SensorData s=new SensorData();
                    if(jo_inside.has("Place_id"))
                        s.Place_id=jo_inside.getString("Place_id");
                    if(jo_inside.has("Place_name"))
                        s.Place_name=jo_inside.getString("Place_name");
                    if(jo_inside.has("Lat"))
                        s.Lat = jo_inside.getString("Lat");
                    if(jo_inside.has("Lng"))
                        s.Lng=jo_inside.getString("Lng");
                    if(jo_inside.has("Year"))
                        s.Year=jo_inside.getString("Year");
                    if(jo_inside.has("Month"))
                        s.Month=jo_inside.getString("Month");
                    if(jo_inside.has("Air_Temperature"))
                        s.Air_Temperature=jo_inside.getString("Air_Temperature");
                    if(jo_inside.has("Water_Temperature"))
                        s.Water_Temperature=jo_inside.getString("Water_Temperature");
                    if(jo_inside.has("DO"))
                        s.DO=jo_inside.getString("DO");
                    if(jo_inside.has("BOD"))
                        s.BOD=jo_inside.getString("BOD");
                    if(jo_inside.has("COD"))
                        s.COD=jo_inside.getString("COD");
                    if(jo_inside.has("pH"))
                        s.pH=jo_inside.getString("pH");
                    if(jo_inside.has("Turbidity"))
                        s.Turbidity=jo_inside.getString("Turbidity");
                    if(jo_inside.has("Conductivity"))
                        s.Conductivity=jo_inside.getString("Conductivity");
                    if(jo_inside.has("TC"))
                        s.TC=jo_inside.getString("TC");
                    if(jo_inside.has("FC"))
                        s.FC=jo_inside.getString("FC");
                    if(jo_inside.has("FS"))
                        s.FS=jo_inside.getString("FS");
                    if(jo_inside.has("Velocity"))
                        s.Velocity=jo_inside.getString("Velocity");
                    if(jo_inside.has("Hardness"))
                        s.Hardness=jo_inside.getString("Hardness");
                    if(jo_inside.has("Alkalinity"))
                        s.Alkalinity=jo_inside.getString("Alkalinity");
                    if(jo_inside.has("Chloride"))
                        s.Chloride=jo_inside.getString("Chloride");
                    if(jo_inside.has("Cadmium"))
                        s.Cadmium=jo_inside.getString("Cadmium");
                    if(jo_inside.has("Chromium"))
                        s.Chromium=jo_inside.getString("Chromium");
                    if(jo_inside.has("Sulphate"))
                        s.Sulphate=jo_inside.getString("Sulphate");
                    if(jo_inside.has("Nickel"))
                        s.Nickel=jo_inside.getString("Nickel");
                    if(jo_inside.has("Iron"))
                        s.Iron=jo_inside.getString("Iron");
                    if(jo_inside.has("Na"))
                        s.Na=jo_inside.getString("Na");
                    GlobalData.sensordata.add(s);
                    GlobalData.Datapoint++;
                }

            } catch (JSONException e) {
                e.printStackTrace();
            }


        } catch (IOException e) {
            e.printStackTrace();
        }



        return totalSize;
    }//end function

    protected void onProgressUpdate(Integer... progress) {
        //setProgressPercent(progress[0]);
    }

    protected void onPostExecute(Long result) {
        // showDialog("Downloaded " + result + " bytes");
    }
}
