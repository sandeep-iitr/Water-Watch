package com.example.admin.myganga;

/**
 * Created by admin on 5/18/2015.
 */
public class Places {

    int Place_id;
    String Place_name;
    String Lat;
    String Lng;
    String Desc;
    Places()
    {
        Place_name="";
        Lat="";
        Lng="";
        Desc="";
        Place_id=-1;
    }
}
