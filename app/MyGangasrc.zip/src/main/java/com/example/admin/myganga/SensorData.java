package com.example.admin.myganga;

/**
 * Created by admin on 5/18/2015.
 */
public class SensorData {

    String	Place_id="";
    String	Place_name="";
    String	Lat="";
    String	Lng="";
    String	Year="";
    String	Month="";
    String	Air_Temperature="";//
    String	Water_Temperature="";//
    String	DO="";//
    String	BOD="";//
    String	COD="";//
    String	pH="";//
    String	Turbidity="";//
    String	Conductivity="";//
    String	TC="";//
    String	FC="";//
    String	FS="";//
    String	Velocity="";//
    String	Hardness="";//
    String	Alkalinity="";//
    String	Chloride="";//
    String	Sulphate="";//
    String	Cadmium="";//
    String	Chromium="";//
    String	Nickel="";//
    String	Iron="";//
    String	Na="";//

    String	TDS="";
    String	Nitrate="";
    //live sensor parameters

    String	source="";
    double	lat=-1;
    double	lng=-1;
    String  date="";
    String  time ="";

    Double	temp=-1.0;
    Double	ph=-1.0;
    Double  mvph=-1.0;
    Double	orpmv=-1.0;
    Double	ecscm=-1.0;
    Double  ecabsscm=-1.0;
    Double  resohmcm=-1.0;
    Double	tdsppm=-1.0;
    Double	salpsu=-1.0;

    Double	sigmat=-1.0;
    Double	presspsi=-1.0;
    Double	Do=-1.0;//do is not allowed
    Double	doppm=-1.0;
    Double	domgl=-1.0;
    Double	turbfnu=-1.0;
    Double	ppmni=-1.0;

}
