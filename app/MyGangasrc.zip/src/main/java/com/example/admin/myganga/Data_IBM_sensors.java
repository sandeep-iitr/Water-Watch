package com.example.admin.myganga;

/**
 * Created by admin on 10/15/2015.
 */
public class Data_IBM_sensors {
    String	source="";
    double	lat=-1;
    double	lng=-1;
    String  date="";
    String  time ="";

    Double	temp=-1.0;
    Double	ph=-1.0;
    Double  mvph=-1.0;
    Double	orpmv=-1.0;
    Double	ecscm=-1.0;
    Double  ecabsscm=-1.0;
    Double  resohmcm=-1.0;
    Double	tdsppm=-1.0;
    Double	salpsu=-1.0;

    Double	sigmat=-1.0;
    Double	presspsi=-1.0;
    Double	Do=-1.0;//do is not allowed
    Double	doppm=-1.0;
    Double	domgl=-1.0;
    Double	turbfnu=-1.0;
    Double	ppmni=-1.0;


}

