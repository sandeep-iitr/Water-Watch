//https://shancarter.github.io/mr-data-converter/

package com.example.admin.myganga;

import android.app.DatePickerDialog;
import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.content.res.Resources;
import android.graphics.Color;
import android.graphics.drawable.Drawable;
import android.os.AsyncTask;
import android.provider.Settings;
import android.support.v4.app.DialogFragment;
import android.support.v7.app.ActionBarActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.Gravity;
import android.view.Menu;
import android.view.MenuItem;
import android.support.v4.app.FragmentActivity;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.Spinner;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;
import android.widget.Toast;

import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.URL;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.Random;


public class PlacesData extends FragmentActivity {

    TextView datatx;
    private TableLayout t1;
    Context cnt;
    Button bt;
    TextView month_show;
     Button go_back,list_places;
    //mapping of months num to data string
    String[] Month_s = {"dummy","Jan", "Feb", "Mar", "Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        cnt= this;

        //read data of the place which is selected

        RelativeLayout layout = new RelativeLayout(this);
        ProgressBar progressBar = new ProgressBar(cnt,null,android.R.attr.progressBarStyleLarge);
        progressBar.setIndeterminate(true);
        progressBar.setVisibility(View.VISIBLE);
        RelativeLayout.LayoutParams params = new RelativeLayout.LayoutParams(100,100);
        params.addRule(RelativeLayout.CENTER_IN_PARENT);
        layout.addView(progressBar,params);
        setContentView(layout);
        DownloadFilesTask dw=new DownloadFilesTask();
        dw.execute();

        //end read data of the place which is selected


    }//end Oncreate

    void show_data_layout()
    {
        setContentView(R.layout.activity_places_data);
        datatx=(TextView)findViewById(R.id.Place_name);
        t1= (TableLayout)findViewById(R.id.main_table);

        //it is not possible as we reach here only when data is there
        //if(GlobalData.Datapoint==0)//read data if not read already

        DispPlaceSensorData();
        bt=(Button) findViewById(R.id.select_date);
        go_back=(Button) findViewById(R.id.go_back);
        list_places=(Button)findViewById(R.id.list_places);
        bt.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                // Perform action on click
                selectDate(null);
            }
        });


        list_places.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                // Perform action on click
                Intent intent = new Intent(cnt, List_places.class);
                startActivity(intent);
            }
        });


        go_back.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                // Perform action on click
                Intent intent = new Intent(cnt,MapsPlacesActivity.class);
                startActivity(intent);

            }
        });


        month_show = (TextView) findViewById(R.id.Month_selected);

        month_show.setText("  " + Month_s[GlobalData.month].toUpperCase() + " " + String.valueOf(GlobalData.Year));
        month_show.setTextColor(Color.WHITE);
        month_show.setTextSize(23);

        datatx.setText(GlobalData.current_marker.toUpperCase());
        datatx.setTextSize(23);
        datatx.setTextColor(Color.WHITE);

        /*
        Spinner spinner = (Spinner) findViewById(R.id.select_purpose_spinner);
// Create an ArrayAdapter using the string array and a default spinner layout
        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this,
                R.array.purpose_array, android.R.layout.simple_spinner_item);
// Specify the layout to use when the list of choices appears
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
// Apply the adapter to the spinner
        spinner.setAdapter(adapter);
    */

        final Button select_purpose =(Button)findViewById(R.id.select_purpose);
        select_purpose.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {

                LinearLayout layout = new LinearLayout(cnt);
                layout.setOrientation(LinearLayout.VERTICAL);
                // layout.setLayoutParams(new LayoutParams(LayoutParams.FILL_PARENT, LayoutParams.WRAP_CONTENT));
                LinearLayout.LayoutParams lparams = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.FILL_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
                LinearLayout.LayoutParams lparams2 = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.FILL_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
                lparams2.gravity= Gravity.CENTER;
                layout.setLayoutParams(lparams2);

                lparams.setMargins(30, 20, 30, 0);

                Button Irrigation=new Button(cnt);

                Button ALL = new Button(cnt);
                Button BATHING = new Button(cnt);
                Button Drinking=new Button(cnt);

                ALL.setLayoutParams(lparams);
                ALL.setText("ALL");
                ALL.setBackgroundResource(R.drawable.roundedbutton);
                BATHING.setLayoutParams(lparams);
                BATHING.setText("Bathing");
                BATHING.setBackgroundResource(R.drawable.roundedbutton);
                Drinking.setLayoutParams(lparams);
                Drinking.setText("Drinking");
                Drinking.setBackgroundResource(R.drawable.roundedbutton);

                Irrigation.setLayoutParams(lparams);
                Irrigation.setText("Irrigation");
                Irrigation.setBackgroundResource(R.drawable.roundedbutton);

                BATHING.setId(10000);
                ALL.setId(101000);
                Drinking.setId(102000);
                Irrigation.setId(103000);




                layout.addView(ALL);
                layout.addView(Drinking);
                layout.addView(BATHING);
                layout.addView(Irrigation);

                layout.setBackgroundResource(R.drawable.female1);
                final Dialog dialog = new Dialog(cnt);
                dialog.setContentView(layout);
                dialog.setTitle("Select Purpose");

                dialog.show();

                Irrigation.setOnClickListener(new View.OnClickListener() {
                    public void onClick(View v) {

                        select_purpose.setText("Selected Purpose : Irrigation");
                        dialog.hide();


                    }
                });

                ALL.setOnClickListener(new View.OnClickListener() {
                    public void onClick(View v) {

                        select_purpose.setText("Selected Purpose : All");
                        dialog.hide();


                    }
                });

                Drinking.setOnClickListener(new View.OnClickListener() {
                    public void onClick(View v) {

                        select_purpose.setText("Selected Purpose : Drinking");
                        dialog.hide();


                    }
                });

                BATHING.setOnClickListener(new View.OnClickListener() {
                    public void onClick(View v) {

                        select_purpose.setText("Selected Purpose : Bathing");
                        dialog.hide();


                    }
                });
            }
        });//end select_purpose.onclick

    }//end show_data_layout

    public void selectDate(View view) {
        DialogFragment newFragment = new SelectDateFragment();
        newFragment.show(getSupportFragmentManager(), "DatePicker");
    }

    void DispPlaceSensorData()
    {

        /*
        //adding sensor data to table
        Resources res = getResources(); //resource handle
        Drawable drawable = res.getDrawable(R.drawable.lightblue);

        t1.removeAllViews();
        TableRow tr_head = new TableRow(cnt);
        int count_id=100000;
       // adding the header row
        tr_head.setId(2000 + count_id++);
        tr_head.setBackgroundDrawable(drawable);

        tr_head.setLayoutParams(new TableRow.LayoutParams(
                TableRow.LayoutParams.FILL_PARENT,
                TableRow.LayoutParams.WRAP_CONTENT));

        TextView label_type = new TextView(cnt);
        label_type.setId(2000 + count_id++);
        label_type.setText("Parameter");
        label_type.setTextSize(20);

        label_type.setTextColor(Color.WHITE);
        label_type.setPadding(5, 5, 5, 5);
        tr_head.addView(label_type);// add the column to the table row here

        TextView label_value = new TextView(cnt);
        label_value.setId(2000 + count_id++);
        label_value.setText("Value"); // set the text for the header
        label_value.setTextColor(Color.WHITE); // set the color
        label_value.setTextSize(20);
        label_value.setPadding(5, 5, 5, 5); // set the padding (if required)
        tr_head.addView(label_value); // add the column to the table row here

        t1.addView(tr_head, new TableLayout.LayoutParams(
                TableLayout.LayoutParams.FILL_PARENT,
                TableLayout.LayoutParams.WRAP_CONTENT));

        //end adding the header row
*/
        //initializing global year, if not selected yet
        if(GlobalData.Year==-1)
        {
            try {
                if (GlobalData.sensordata.size() > 0) {
                    GlobalData.Year = Integer.valueOf(GlobalData.sensordata.get(0).Year);
                }//end if
            }//end try
            catch (NumberFormatException e) {
                e.printStackTrace();
            }

        }//end if(GlobalData.Year)
        //adding the data rows
        for (int i = 0; i < GlobalData.sensordata.size(); i++) {
            SensorData sensor = GlobalData.sensordata.get(i);
            if (sensor != null) {

           //     if(sensor.Place_name.equals(GlobalData.current_marker)&&sensor.Month.equals(Month_s[GlobalData.month])&&GlobalData.Year==Integer.parseInt(sensor.Year))
                if(sensor.Month.equals(Month_s[GlobalData.month])&&GlobalData.Year==Integer.parseInt(sensor.Year))
                {

                    if(GlobalData.lg==null)//creating a dummy object to remove further null checks
                        GlobalData.lg=new Limits_general();

                    String padding="";
                    padding="("+GlobalData.lg.Air_Temperature_min+"->"+GlobalData.lg.Air_Temperature_max+")";
                    TextView air_temp=(TextView)findViewById(R.id.air_temp_data);
                    if(padding.length()<=4) padding="";
                    air_temp.setText(sensor.Air_Temperature+padding);

                    TextView water_temp=(TextView)findViewById(R.id.water_temp_data);
                    padding="("+GlobalData.lg.Water_Temperature_min +"->"+GlobalData.lg.Water_Temperature_max +")";
                    if(padding.length()<=4) padding="";
                    water_temp.setText(sensor.Water_Temperature+padding);


                    TextView DO=(TextView)findViewById(R.id.do_data);
                    padding="("+GlobalData.lg.DO_min +"->"+GlobalData.lg.DO_max +")";
                    if(padding.length()<=4) padding="";
                    DO.setText(sensor.DO+padding);

                    TextView bod=(TextView)findViewById(R.id.bod_data);
                    padding="("+GlobalData.lg.BOD_min +"->"+GlobalData.lg.BOD_max +")";
                    if(padding.length()<=4) padding="";
                    bod.setText(sensor.BOD+padding);

                    TextView cod=(TextView)findViewById(R.id.cod_data);
                    padding="("+GlobalData.lg.COD_min +"->"+GlobalData.lg.COD_max +")";
                    if(padding.length()<=4) padding="";
                    cod.setText(sensor.COD+padding);

                    TextView ph=(TextView)findViewById(R.id.ph_data);
                    padding="("+GlobalData.lg.pH_min +"->"+GlobalData.lg.pH_max +")";
                    if(padding.length()<=4) padding="";
                    ph.setText(sensor.pH+padding);


                    TextView turbidity=(TextView)findViewById(R.id.turbidity_data);
                    padding="("+GlobalData.lg.Turbidity_min +"->"+GlobalData.lg.Turbidity_max +")";
                    if(padding.length()<=4) padding="";
                    turbidity.setText(sensor.Turbidity+padding);

                    TextView conductivity=(TextView)findViewById(R.id.conductivity_data);
                    padding="("+GlobalData.lg.Conductivity_min +"->"+GlobalData.lg.Conductivity_max +")";
                    if(padding.length()<=4) padding="";
                    conductivity.setText(sensor.Conductivity+padding);

                    TextView tc=(TextView)findViewById(R.id.tc_data);
                    padding="("+GlobalData.lg.TC_min +"->"+GlobalData.lg.TC_max +")";
                    if(padding.length()<=4) padding="";
                    tc.setText(sensor.TC+padding);

                    TextView fs=(TextView)findViewById(R.id.fs_data);
                    padding="("+GlobalData.lg.FS_min +"->"+GlobalData.lg.FS_max +")";
                    if(padding.length()<=4) padding="";
                    fs.setText(sensor.FS+padding);

                    TextView fc=(TextView)findViewById(R.id.fc_data);
                    padding="("+GlobalData.lg.FC_min +"->"+GlobalData.lg.FC_max +")";
                    if(padding.length()<=4) padding="";
                    fc.setText(sensor.FC+padding);

                    TextView velocity=(TextView)findViewById(R.id.velocity_data);
                    padding="("+GlobalData.lg.Velocity_min +"->"+GlobalData.lg.Velocity_max +")";
                    if(padding.length()<=4) padding="";
                    velocity.setText(sensor.Velocity+padding);

                    TextView hardness=(TextView)findViewById(R.id.hardness_data);
                    padding="("+GlobalData.lg.Hardness_min +"->"+GlobalData.lg.Hardness_max +")";
                    if(padding.length()<=4) padding="";
                    hardness.setText(sensor.Hardness+padding);

                    TextView alkalinity=(TextView)findViewById(R.id.alkalinity_data);
                    padding="("+GlobalData.lg.Alkalinity_min +"->"+GlobalData.lg.Alkalinity_max +")";
                    if(padding.length()<=4) padding="";
                    alkalinity.setText(sensor.Alkalinity+padding);

                    TextView chloride=(TextView)findViewById(R.id.chloride_data);
                    padding="("+GlobalData.lg.Chloride_min +"->"+GlobalData.lg.Chloride_max +")";
                    if(padding.length()<=4) padding="";
                    chloride.setText(sensor.Chloride+padding);

                    TextView sulphate=(TextView)findViewById(R.id.sulphate_data);
                    padding="("+GlobalData.lg.Sulphate_min +"->"+GlobalData.lg.Sulphate_max +")";
                    if(padding.length()<=4) padding="";
                    sulphate.setText(sensor.Sulphate+padding);

                    TextView cadmium=(TextView)findViewById(R.id.cadmium_data);
                    padding="("+GlobalData.lg.Cadmium_min +"->"+GlobalData.lg.Cadmium_max +")";
                    if(padding.length()<=4) padding="";
                    cadmium.setText(sensor.Cadmium+padding);


                    TextView chromium=(TextView)findViewById(R.id.chromium_data);
                    padding="("+GlobalData.lg.Chromium_min +"->"+GlobalData.lg.Chromium_max +")";
                    if(padding.length()<=4) padding="";
                    chromium.setText(sensor.Chromium+padding);

                    TextView nickel=(TextView)findViewById(R.id.nickel_data);
                    padding="("+GlobalData.lg.Nickel_min +"->"+GlobalData.lg.Nickel_max +")";
                    if(padding.length()<=4) padding="";
                    nickel.setText(sensor.Nickel+padding);

                    TextView iron=(TextView)findViewById(R.id.iron_data);
                    padding="("+GlobalData.lg.Iron_min +"->"+GlobalData.lg.Iron_max +")";
                    if(padding.length()<=4) padding="";
                    iron.setText(sensor.Iron+padding);

                    TextView na=(TextView)findViewById(R.id.na_data);
                    padding="("+GlobalData.lg.Na_min +"->"+GlobalData.lg.Na_max +")";
                    if(padding.length()<=4) padding="";
                    na.setText(sensor.Na+padding);



                    //limits checking
                    if(GlobalData.lg!=null) {
                        try {
                            if (!GlobalData.lg.Air_Temperature_min.isEmpty()) {
                                if (Double.parseDouble(sensor.Air_Temperature) < Double.parseDouble(GlobalData.lg.Air_Temperature_min))
                                    air_temp.setTextColor(Color.RED);
                            }

                            if (!GlobalData.lg.Air_Temperature_max.isEmpty()) {
                                if (Double.parseDouble(sensor.Air_Temperature) > Double.parseDouble(GlobalData.lg.Air_Temperature_max))
                                    air_temp.setTextColor(Color.RED);
                            }

                        }//end try
                        catch (NumberFormatException e) {
                            e.printStackTrace();
                        }

                        try{

                            if (!GlobalData.lg.Water_Temperature_min.isEmpty()) {
                                if (Double.parseDouble(sensor.Water_Temperature) < Double.parseDouble(GlobalData.lg.Water_Temperature_min))
                                    water_temp.setTextColor(Color.RED);
                            }

                            if (!GlobalData.lg.Water_Temperature_max.isEmpty()) {
                                if (Double.parseDouble(sensor.Water_Temperature) > Double.parseDouble(GlobalData.lg.Water_Temperature_max))
                                    water_temp.setTextColor(Color.RED);
                            }

                        }//end try
                        catch (NumberFormatException e) {
                            e.printStackTrace();
                        }

                        try{

                            if (!GlobalData.lg.DO_min.isEmpty()) {
                                if (Double.parseDouble(sensor.DO) < Double.parseDouble(GlobalData.lg.DO_min))
                                    DO.setTextColor(Color.RED);
                            }

                            if (!GlobalData.lg.DO_max.isEmpty()) {
                                if (Double.parseDouble(sensor.DO) > Double.parseDouble(GlobalData.lg.DO_max))
                                    DO.setTextColor(Color.RED);
                            }

                        }//end try
                        catch (NumberFormatException e) {
                            e.printStackTrace();
                        }

                        try {
                            if (!GlobalData.lg.BOD_min.isEmpty()) {
                                if (Double.parseDouble(sensor.BOD) < Double.parseDouble(GlobalData.lg.BOD_min))
                                    bod.setTextColor(Color.RED);
                            }

                            if (!GlobalData.lg.BOD_max.isEmpty()) {
                                if (Double.parseDouble(sensor.BOD) > Double.parseDouble(GlobalData.lg.BOD_max))
                                    bod.setTextColor(Color.RED);
                            }

                        }//end try
                        catch (NumberFormatException e) {
                            e.printStackTrace();
                        }

                        try
                        {
                            if (!GlobalData.lg.COD_min.isEmpty()) {
                                if (Double.parseDouble(sensor.COD) < Double.parseDouble(GlobalData.lg.COD_min))
                                    cod.setTextColor(Color.RED);
                            }

                            if (!GlobalData.lg.COD_max.isEmpty()) {
                                if (Double.parseDouble(sensor.COD) > Double.parseDouble(GlobalData.lg.COD_max))
                                    cod.setTextColor(Color.RED);
                            }
                        }//end try
                        catch (NumberFormatException e) {
                            e.printStackTrace();
                        }

                         try
                         {
                            if (!GlobalData.lg.pH_min.isEmpty()) {
                                if (Double.parseDouble(sensor.pH) < Double.parseDouble(GlobalData.lg.pH_min))
                                    ph.setTextColor(Color.RED);
                            }

                            if (!GlobalData.lg.pH_max.isEmpty()) {
                                if (Double.parseDouble(sensor.pH) > Double.parseDouble(GlobalData.lg.pH_max))
                                    ph.setTextColor(Color.RED);
                            }
                         }//end try
                         catch (NumberFormatException e) {
                             e.printStackTrace();
                         }

                        try{


                            if (!GlobalData.lg.Turbidity_min.isEmpty()) {
                                if (Double.parseDouble(sensor.Turbidity) < Double.parseDouble(GlobalData.lg.Turbidity_min))
                                    turbidity.setTextColor(Color.RED);
                            }

                            if (!GlobalData.lg.Turbidity_max.isEmpty()) {
                                if (Double.parseDouble(sensor.Turbidity) > Double.parseDouble(GlobalData.lg.Turbidity_max))
                                    turbidity.setTextColor(Color.RED);
                            }

                        }//end try
                        catch (NumberFormatException e) {
                            e.printStackTrace();
                        }

                        try
                        {
                            if (!GlobalData.lg.Conductivity_min.isEmpty()) {
                                if (Double.parseDouble(sensor.Conductivity) < Double.parseDouble(GlobalData.lg.Conductivity_min))
                                    conductivity.setTextColor(Color.RED);
                            }

                            if (!GlobalData.lg.Conductivity_max.isEmpty()) {
                                if (Double.parseDouble(sensor.Conductivity) > Double.parseDouble(GlobalData.lg.Conductivity_max))
                                    conductivity.setTextColor(Color.RED);
                            }

                        }//end try
                        catch (NumberFormatException e) {
                            e.printStackTrace();
                        }

                        try{
                            if (!GlobalData.lg.TC_min.isEmpty()) {
                                if (Double.parseDouble(sensor.TC) < Double.parseDouble(GlobalData.lg.TC_min))
                                    tc.setTextColor(Color.RED);
                            }

                            if (!GlobalData.lg.TC_max.isEmpty()) {
                                if (Double.parseDouble(sensor.TC) > Double.parseDouble(GlobalData.lg.TC_max))
                                    tc.setTextColor(Color.RED);
                            }

                        }//end try
                        catch (NumberFormatException e) {
                            e.printStackTrace();
                        }

                        try
                        {
                            if (!GlobalData.lg.FC_min.isEmpty()) {
                                if (Double.parseDouble(sensor.FC) < Double.parseDouble(GlobalData.lg.FC_min))
                                    fc.setTextColor(Color.RED);
                            }

                            if (!GlobalData.lg.FC_max.isEmpty()) {
                                if (Double.parseDouble(sensor.FC) > Double.parseDouble(GlobalData.lg.FC_max))
                                    fc.setTextColor(Color.RED);
                            }

                        }//end try
                        catch (NumberFormatException e) {
                            e.printStackTrace();
                        }

                         try
                         {
                            if (!GlobalData.lg.FS_min.isEmpty()) {
                                if (Double.parseDouble(sensor.FS) < Double.parseDouble(GlobalData.lg.FS_min))
                                    fs.setTextColor(Color.RED);
                            }

                            if (!GlobalData.lg.FS_max.isEmpty()) {
                                if (Double.parseDouble(sensor.FS) > Double.parseDouble(GlobalData.lg.FS_max))
                                    fs.setTextColor(Color.RED);
                            }

                         }//end try
                         catch (NumberFormatException e) {
                             e.printStackTrace();
                         }

                        try
                        {
                            if (!GlobalData.lg.Velocity_min.isEmpty()) {
                                if (Double.parseDouble(sensor.Velocity) < Double.parseDouble(GlobalData.lg.Velocity_min))
                                    velocity.setTextColor(Color.RED);
                            }

                            if (!GlobalData.lg.Velocity_max.isEmpty()) {
                                if (Double.parseDouble(sensor.Velocity) > Double.parseDouble(GlobalData.lg.Velocity_max))
                                    velocity.setTextColor(Color.RED);
                            }

                        }//end try
                        catch (NumberFormatException e) {
                            e.printStackTrace();
                        }

                        try
                        {

                            if (!GlobalData.lg.Hardness_min.isEmpty()) {
                                if (Double.parseDouble(sensor.Hardness) < Double.parseDouble(GlobalData.lg.Hardness_min))
                                    hardness.setTextColor(Color.RED);
                            }

                            if (!GlobalData.lg.Hardness_max.isEmpty()) {
                                if (Double.parseDouble(sensor.Hardness) > Double.parseDouble(GlobalData.lg.Hardness_max))
                                    hardness.setTextColor(Color.RED);
                            }

                        }//end try
                        catch (NumberFormatException e) {
                            e.printStackTrace();
                        }

                        try
                        {
                            if (!GlobalData.lg.Alkalinity_min.isEmpty()) {
                                if (Double.parseDouble(sensor.Alkalinity) < Double.parseDouble(GlobalData.lg.Alkalinity_min))
                                    alkalinity.setTextColor(Color.RED);
                            }

                            if (!GlobalData.lg.Alkalinity_max.isEmpty()) {
                                if (Double.parseDouble(sensor.Alkalinity) > Double.parseDouble(GlobalData.lg.Alkalinity_max))
                                    alkalinity.setTextColor(Color.RED);
                            }

                        }//end try
                        catch (NumberFormatException e) {
                            e.printStackTrace();
                        }


                        try
                        {
                            if (!GlobalData.lg.Chloride_min.isEmpty()) {
                                if (Double.parseDouble(sensor.Chloride) < Double.parseDouble(GlobalData.lg.Chloride_min))
                                    chloride.setTextColor(Color.RED);
                            }

                            if (!GlobalData.lg.Chloride_max.isEmpty()) {
                                if (Double.parseDouble(sensor.Chloride) > Double.parseDouble(GlobalData.lg.Chloride_max))
                                    chloride.setTextColor(Color.RED);
                            }

                        }//end try
                        catch (NumberFormatException e) {
                            e.printStackTrace();
                        }

                        try
                        {
                            if (!GlobalData.lg.Sulphate_min.isEmpty()) {
                                if (Double.parseDouble(sensor.Sulphate) < Double.parseDouble(GlobalData.lg.Sulphate_min))
                                    sulphate.setTextColor(Color.RED);
                            }

                            if (!GlobalData.lg.Sulphate_max.isEmpty()) {
                                if (Double.parseDouble(sensor.Sulphate) > Double.parseDouble(GlobalData.lg.Sulphate_max))
                                    sulphate.setTextColor(Color.RED);
                            }

                        }//end try
                        catch (NumberFormatException e) {
                            e.printStackTrace();
                        }

                        try
                        {

                            if (!GlobalData.lg.Cadmium_min.isEmpty()) {
                                if (Double.parseDouble(sensor.Cadmium) < Double.parseDouble(GlobalData.lg.Cadmium_min))
                                    cadmium.setTextColor(Color.RED);
                            }

                            if (!GlobalData.lg.Cadmium_max.isEmpty()) {
                                if (Double.parseDouble(sensor.Cadmium) > Double.parseDouble(GlobalData.lg.Cadmium_max))
                                    cadmium.setTextColor(Color.RED);
                            }

                        }//end try
                        catch (NumberFormatException e) {
                            e.printStackTrace();
                        }

                        try
                        {
                            if (!GlobalData.lg.Chromium_min.isEmpty()) {
                                if (Double.parseDouble(sensor.Chromium) < Double.parseDouble(GlobalData.lg.Chromium_min))
                                    chromium.setTextColor(Color.RED);
                            }

                            if (!GlobalData.lg.Chromium_max.isEmpty()) {
                                if (Double.parseDouble(sensor.Chromium) > Double.parseDouble(GlobalData.lg.Chromium_max))
                                    chromium.setTextColor(Color.RED);
                            }


                        }//end try
                        catch (NumberFormatException e) {
                            e.printStackTrace();
                        }

                        try
                        {
                            if (!GlobalData.lg.Nickel_min.isEmpty()) {
                                if (Double.parseDouble(sensor.Nickel) < Double.parseDouble(GlobalData.lg.Nickel_min))
                                    nickel.setTextColor(Color.RED);
                            }

                            if (!GlobalData.lg.Nickel_max.isEmpty()) {
                                if (Double.parseDouble(sensor.Nickel) > Double.parseDouble(GlobalData.lg.Nickel_max))
                                    nickel.setTextColor(Color.RED);
                            }

                        }//end try
                        catch (NumberFormatException e) {
                            e.printStackTrace();
                        }

                        try
                        {
                            if (!GlobalData.lg.Iron_min.isEmpty()) {
                                if (Double.parseDouble(sensor.Iron) < Double.parseDouble(GlobalData.lg.Iron_min))
                                    iron.setTextColor(Color.RED);
                            }

                            if (!GlobalData.lg.Iron_max.isEmpty()) {
                                if (Double.parseDouble(sensor.Iron) > Double.parseDouble(GlobalData.lg.Iron_max))
                                    iron.setTextColor(Color.RED);
                            }

                        }//end try
                        catch (NumberFormatException e) {
                            e.printStackTrace();
                        }

                        try
                        {
                            if (!GlobalData.lg.Na_min.isEmpty()) {
                                if (Double.parseDouble(sensor.Na) < Double.parseDouble(GlobalData.lg.Na_min))
                                    na.setTextColor(Color.RED);
                            }

                            if (!GlobalData.lg.Na_max.isEmpty()) {
                                if (Double.parseDouble(sensor.Na) > Double.parseDouble(GlobalData.lg.Na_max))
                                    na.setTextColor(Color.RED);
                            }


                        }//end try
                        catch (NumberFormatException e) {
                            e.printStackTrace();
                        }

                    }//end  if(GlobalData.lg!=null)

                }//end if
                else
                {
                   // Toast.makeText(cnt,"not equal: "+GlobalData.current_marker+sensor.place_name, Toast.LENGTH_SHORT).show();// display toast
                   // Log.d("Details-->","not equal: "+GlobalData.current_marker+sensor.place_name );
                }//end else
            }
            //System.out.println("Index: " + i + " - Item: " + list.get(i));
        }


        //end adding the data rows
        //end adding sensor data to table

    }



    public void populateSetDate(int year, int month, int day) {
       // Button bt = (Button)findViewById(R.id.select_date);
        //bt.setText(month + "/" + day + "/" + year);
        GlobalData.month=month;
        GlobalData.Year=year;
        Intent intent =new Intent(cnt,PlacesData.class);
        startActivity(intent);

    }


    public  class SelectDateFragment extends DialogFragment implements DatePickerDialog.OnDateSetListener {
        @Override
        public Dialog onCreateDialog(Bundle savedInstanceState) {
            final Calendar calendar = Calendar.getInstance();
            int yy = calendar.get(Calendar.YEAR);
            int mm = calendar.get(Calendar.MONTH);
            int dd = calendar.get(Calendar.DAY_OF_MONTH);
            return new DatePickerDialog(getActivity(), this, yy, mm, dd);
        }

        public void onDateSet(DatePicker view, int yy, int mm, int dd) {
            populateSetDate(yy, mm+1, dd);
        }
    }





    private class DownloadFilesTask extends AsyncTask<URL, Integer, Long> {
        protected Long doInBackground(URL... urls) {
            //  int count = urls.length;
            long totalSize = 0;
            DefaultHttpClient httpclient = new DefaultHttpClient();

            //////////////////////////////////////////////////////////////
            // loading data of places, thie place which is clicked is set in the global data structures

           HttpPost  httppostreq = new HttpPost("http://cdata.mybluemix.net/Send_places_data");
            try {

                List<NameValuePair> params = new ArrayList<NameValuePair>();
               // params.add(new BasicNameValuePair("key", "value"));
                //if(GlobalData.place_position>=0)
                params.add(new BasicNameValuePair("key", "value"));
                params.add(new BasicNameValuePair("Place_id", "-1"));//we donot store this now
                params.add(new BasicNameValuePair("Lat", GlobalData.current_Lat));
                params.add(new BasicNameValuePair("Lng", GlobalData.current_Lng));
                params.add(new BasicNameValuePair("range","1.0"));//in KM

                httppostreq.setEntity(new UrlEncodedFormEntity(params));
                HttpResponse httpresponse = httpclient.execute(httppostreq);

                InputStream stream=httpresponse.getEntity().getContent();
                BufferedReader reader = new BufferedReader(new InputStreamReader(
                        stream, "UTF-8"), 8);
                StringBuilder sb = new StringBuilder();
                String line = null;
                while ((line = reader.readLine()) != null) {
                    sb.append(line + "\n");
                }
                String response2 = sb.toString();
                stream.close();
                //
                //Toast.makeText(cnt, stream.toString(), Toast.LENGTH_SHORT).show();
                Log.d("cloud server","stream from server"+ response2);

                //places are in response string
                try {
                    JSONArray jsonArray = new JSONArray(response2);

                    //clearing already read places in the memory
                    if(GlobalData.Datapoint>0)
                    {
                        GlobalData.Datapoint=0;
                        GlobalData.sensordata.clear();
                    }


                    for (int i = 0; i < jsonArray.length(); i++) {
                        JSONObject jo_inside = jsonArray.getJSONObject(i);
                        if(jo_inside.has("Place_name"))
                        Log.d("Details-data->", jo_inside.getString("Place_name"));

                        SensorData s=new SensorData();
                        if(jo_inside.has("Place_id"))
                            s.Place_id=jo_inside.getString("Place_id");
                        if(jo_inside.has("Place_name"))
                            s.Place_name=jo_inside.getString("Place_name");
                        if(jo_inside.has("Lat"))
                            s.Lat = jo_inside.getString("Lat");
                        if(jo_inside.has("Lng"))
                            s.Lng=jo_inside.getString("Lng");
                        if(jo_inside.has("Year"))
                            s.Year=jo_inside.getString("Year");
                        if(jo_inside.has("Month"))
                            s.Month=jo_inside.getString("Month");
                        if(jo_inside.has("Air_Temperature"))
                            s.Air_Temperature=jo_inside.getString("Air_Temperature");
                        if(jo_inside.has("Water_Temperature"))
                            s.Water_Temperature=jo_inside.getString("Water_Temperature");
                        if(jo_inside.has("DO"))
                            s.DO=jo_inside.getString("DO");
                        if(jo_inside.has("BOD"))
                            s.BOD=jo_inside.getString("BOD");
                        if(jo_inside.has("COD"))
                            s.COD=jo_inside.getString("COD");
                        if(jo_inside.has("pH"))
                            s.pH=jo_inside.getString("pH");
                        if(jo_inside.has("Turbidity"))
                            s.Turbidity=jo_inside.getString("Turbidity");
                        if(jo_inside.has("Conductivity"))
                            s.Conductivity=jo_inside.getString("Conductivity");
                        if(jo_inside.has("TC"))
                            s.TC=jo_inside.getString("TC");
                        if(jo_inside.has("FC"))
                            s.FC=jo_inside.getString("FC");
                        if(jo_inside.has("FS"))
                            s.FS=jo_inside.getString("FS");
                        if(jo_inside.has("Velocity"))
                            s.Velocity=jo_inside.getString("Velocity");
                        if(jo_inside.has("Hardness"))
                            s.Hardness=jo_inside.getString("Hardness");
                        if(jo_inside.has("Alkalinity"))
                            s.Alkalinity=jo_inside.getString("Alkalinity");
                        if(jo_inside.has("Chloride"))
                            s.Chloride=jo_inside.getString("Chloride");
                        if(jo_inside.has("Cadmium"))
                            s.Cadmium=jo_inside.getString("Cadmium");
                        if(jo_inside.has("Chromium"))
                            s.Chromium=jo_inside.getString("Chromium");
                        if(jo_inside.has("Sulphate"))
                            s.Sulphate=jo_inside.getString("Sulphate");
                        if(jo_inside.has("Nickel"))
                            s.Nickel=jo_inside.getString("Nickel");
                        if(jo_inside.has("Iron"))
                            s.Iron=jo_inside.getString("Iron");
                        if(jo_inside.has("Na"))
                            s.Na=jo_inside.getString("Na");


                        GlobalData.sensordata.add(s);
                        GlobalData.Datapoint++;

                    }

                } catch (JSONException e) {
                    e.printStackTrace();
                }


            } catch (IOException e) {
                e.printStackTrace();
            }


            //loading general_limits of different parameters

            httppostreq = new HttpPost("http://cdata.mybluemix.net/Send_limit_general");
            try {
                HttpResponse httpresponse = httpclient.execute(httppostreq);

                InputStream stream=httpresponse.getEntity().getContent();
                BufferedReader reader = new BufferedReader(new InputStreamReader(
                        stream, "UTF-8"), 8);
                StringBuilder sb = new StringBuilder();
                String line = null;
                while ((line = reader.readLine()) != null) {
                    sb.append(line + "\n");
                }
                String response = sb.toString();
                stream.close();
                //
                //Toast.makeText(cnt, stream.toString(), Toast.LENGTH_SHORT).show();
                Log.d("cloud server", "stream from server" + response);

                //places are in response string
                try {
                    JSONArray jsonArray = new JSONArray(response);

                    for (int i = 0; i < jsonArray.length(); i++) {
                        JSONObject jo_inside = jsonArray.getJSONObject(i);
                        if(jo_inside.has("DO_min"))
                        Log.d("Details limits-->", jo_inside.getString("DO_min"));
                        GlobalData.lg=new Limits_general();

                        if(jo_inside.has("Air_Temperature_max"))
                            GlobalData.lg.Air_Temperature_max=jo_inside.getString("Air_Temperature_max");
                        if(jo_inside.has("Water_Temperature_max"))
                            GlobalData.lg.Water_Temperature_max=jo_inside.getString("Water_Temperature_max");
                        if(jo_inside.has("DO_max"))
                            GlobalData.lg.DO_max=jo_inside.getString("DO_max");
                        if(jo_inside.has("BOD_max"))
                            GlobalData.lg.BOD_max=jo_inside.getString("BOD_max");
                        if(jo_inside.has("COD_max"))
                            GlobalData.lg.COD_max=jo_inside.getString("COD_max");
                        if(jo_inside.has("pH_max"))
                            GlobalData.lg.pH_max=jo_inside.getString("pH_max");
                        if(jo_inside.has("Turbidity_max"))
                            GlobalData.lg.Turbidity_max=jo_inside.getString("Turbidity_max");
                        if(jo_inside.has("Conductivity_max"))
                            GlobalData.lg.Conductivity_max=jo_inside.getString("Conductivity_max");
                        if(jo_inside.has("TC_max"))
                            GlobalData.lg.TC_max=jo_inside.getString("TC_max");
                        if(jo_inside.has("FC_max"))
                            GlobalData.lg.FC_max=jo_inside.getString("FC_max");
                        if(jo_inside.has("FS_max"))
                            GlobalData.lg.FS_max=jo_inside.getString("FS_max");
                        if(jo_inside.has("Velocity_max"))
                            GlobalData.lg.Velocity_max=jo_inside.getString("Velocity_max");
                        if(jo_inside.has("Hardness_max"))
                            GlobalData.lg.Hardness_max=jo_inside.getString("Hardness_max");
                        if(jo_inside.has("Alkalinity_max"))
                            GlobalData.lg.Alkalinity_max=jo_inside.getString("Alkalinity_max");
                        if(jo_inside.has("Chloride_max"))
                            GlobalData.lg.Chloride_max=jo_inside.getString("Chloride_max");
                        if(jo_inside.has("Cadmium_max"))
                            GlobalData.lg.Cadmium_max=jo_inside.getString("Cadmium_max");
                        if(jo_inside.has("Chromium_max"))
                            GlobalData.lg.Chromium_max=jo_inside.getString("Chromium_max");
                        if(jo_inside.has("Sulphate_max"))
                            GlobalData.lg.Sulphate_max=jo_inside.getString("Sulphate_max");
                        if(jo_inside.has("Nickel_max"))
                            GlobalData.lg.Nickel_max=jo_inside.getString("Nickel_max");
                        if(jo_inside.has("Iron_max"))
                            GlobalData.lg.Iron_max=jo_inside.getString("Iron_max");
                        if(jo_inside.has("Na_max"))
                            GlobalData.lg.Na_max=jo_inside.getString("Na_max");

                        if(jo_inside.has("Air_Temperature_min"))
                            GlobalData.lg.Air_Temperature_min=jo_inside.getString("Air_Temperature_min");
                        if(jo_inside.has("Water_Temperature_min"))
                            GlobalData.lg.Water_Temperature_min=jo_inside.getString("Water_Temperature_min");
                        if(jo_inside.has("DO_min"))
                            GlobalData.lg.DO_min=jo_inside.getString("DO_min");
                        if(jo_inside.has("BOD_min"))
                            GlobalData.lg.BOD_min=jo_inside.getString("BOD_min");
                        if(jo_inside.has("COD_min"))
                            GlobalData.lg.COD_min=jo_inside.getString("COD_min");
                        if(jo_inside.has("pH_min"))
                            GlobalData.lg.pH_min=jo_inside.getString("pH_min");
                        if(jo_inside.has("Turbidity_min"))
                            GlobalData.lg.Turbidity_min=jo_inside.getString("Turbidity_min");
                        if(jo_inside.has("Conductivity_min"))
                            GlobalData.lg.Conductivity_min=jo_inside.getString("Conductivity_min");
                        if(jo_inside.has("TC_min"))
                            GlobalData.lg.TC_min=jo_inside.getString("TC_min");
                        if(jo_inside.has("FC_min"))
                            GlobalData.lg.FC_min=jo_inside.getString("FC_min");
                        if(jo_inside.has("FS_min"))
                            GlobalData.lg.FS_min=jo_inside.getString("FS_min");
                        if(jo_inside.has("Velocity_min"))
                            GlobalData.lg.Velocity_min=jo_inside.getString("Velocity_min");
                        if(jo_inside.has("Hardness_min"))
                            GlobalData.lg.Hardness_min=jo_inside.getString("Hardness_min");
                        if(jo_inside.has("Alkalinity_min"))
                            GlobalData.lg.Alkalinity_min=jo_inside.getString("Alkalinity_min");
                        if(jo_inside.has("Chloride_min"))
                            GlobalData.lg.Chloride_min=jo_inside.getString("Chloride_min");
                        if(jo_inside.has("Cadmium_min"))
                            GlobalData.lg.Cadmium_min=jo_inside.getString("Cadmium_min");
                        if(jo_inside.has("Chromium_min"))
                            GlobalData.lg.Chromium_min=jo_inside.getString("Chromium_min");
                        if(jo_inside.has("Sulphate_min"))
                            GlobalData.lg.Sulphate_min=jo_inside.getString("Sulphate_min");
                        if(jo_inside.has("Nickel_min"))
                            GlobalData.lg.Nickel_min=jo_inside.getString("Nickel_min");
                        if(jo_inside.has("Iron_min"))
                            GlobalData.lg.Iron_min=jo_inside.getString("Iron_min");
                        if(jo_inside.has("Na_min"))
                            GlobalData.lg.Na_min=jo_inside.getString("Na_min");
                    }

                } catch (JSONException e) {
                    e.printStackTrace();
                }


            } catch (IOException e) {
                e.printStackTrace();
            }
//end loading limits of general parameters



            return totalSize;
        }//end function

        protected void onProgressUpdate(Integer... progress) {
            //setProgressPercent(progress[0]);
        }

        protected void onPostExecute(Long result) {
            // showDialog("Downloaded " + result + " bytes");

            // Intent intent = new Intent(cnt, List_places.class);
            //startActivity(intent);

            show_data_layout();

        }//end onpost
    }



}
