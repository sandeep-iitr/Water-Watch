package com.example.admin.myganga;

import android.app.Activity;
import android.app.ListActivity;
import android.content.Context;
import android.content.Intent;
import android.os.AsyncTask;
import android.support.v7.app.ActionBarActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.Toast;

import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;

import org.apache.http.HttpResponse;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.URL;
import java.util.ArrayList;


public class List_places extends Activity {

    ListView listView ;
   Context cnt;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        cnt=this;
        //loading data of places from json file
        if(GlobalData.numPlaces==0)//read data if not read already
        {
            RelativeLayout layout = new RelativeLayout(this);
            ProgressBar progressBar = new ProgressBar(cnt,null,android.R.attr.progressBarStyleLarge);
            progressBar.setIndeterminate(true);
            progressBar.setVisibility(View.VISIBLE);
            RelativeLayout.LayoutParams params = new RelativeLayout.LayoutParams(100,100);
            params.addRule(RelativeLayout.CENTER_IN_PARENT);
            layout.addView(progressBar,params);
            setContentView(layout);
            DownloadFilesTask dw=new DownloadFilesTask();
            dw.execute();
        }//end if
        else
        {
            setContentView(R.layout.activity_list_places);
            listView = (ListView) findViewById(R.id.list_of_places);
            //LIST OF ARRAY STRINGS WHICH WILL SERVE AS LIST ITEMS
            ArrayList<String> listItems = new ArrayList<String>();
            //DEFINING A STRING ADAPTER WHICH WILL HANDLE THE DATA OF THE LISTVIEW
            ArrayAdapter<String> adapter;

            adapter = new ArrayAdapter<String>(this,
                    android.R.layout.simple_list_item_1, android.R.id.text1,
                    listItems);

            // Assign adapter to ListView
            listView.setAdapter(adapter);
            AddListItems(listItems);
            adapter.notifyDataSetChanged();
            // ListView Item Click Listener
            listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {

                @Override
                public void onItemClick(AdapterView<?> parent, View view,
                                        int position, long id) {
                    // ListView Clicked item index
                    int itemPosition = position;
                    // ListView Clicked item value
                    String itemValue = (String) listView.getItemAtPosition(position);
                    // Show Alert
                    Toast.makeText(cnt,"Position :" + itemPosition + "  ListItem : " + itemValue, Toast.LENGTH_LONG).show();
                    GlobalData.current_marker = itemValue;
                    //GlobalData.place_position=itemPosition;

                    Places p =GlobalData.place.get(itemPosition);
                    GlobalData.current_Lat=p.Lat;
                    GlobalData.current_Lng=p.Lng;

                    Intent intent = new Intent(getApplicationContext(), PlacesData2.class);
                    startActivity(intent);

                }

            });

        }//end else

    }

    void AddListItems(ArrayList<String> listItems)
    {
        //adding markers of all places present in the global file
        for (Places P : GlobalData.place) {

            listItems.add(P.Place_name);

        }

    }


    private class DownloadFilesTask extends AsyncTask<URL, Integer, Long> {
        protected Long doInBackground(URL... urls) {
            //  int count = urls.length;
            long totalSize = 0;
            DefaultHttpClient httpclient = new DefaultHttpClient();
            HttpPost httppostreq = new HttpPost("http://cdata.mybluemix.net/Send_places");

            try {
                HttpResponse httpresponse = httpclient.execute(httppostreq);

                InputStream stream=httpresponse.getEntity().getContent();
                BufferedReader reader = new BufferedReader(new InputStreamReader(
                        stream, "UTF-8"), 8);
                StringBuilder sb = new StringBuilder();
                String line = null;
                while ((line = reader.readLine()) != null) {
                    sb.append(line + "\n");
                }
                String response = sb.toString();
                stream.close();
                //
                //Toast.makeText(cnt, stream.toString(), Toast.LENGTH_SHORT).show();
                Log.d("cloud server", "stream from server" + response);

                //places are in response string
                try {
                    JSONArray jsonArray = new JSONArray(response);


                    //clearing already read places in the memory
                    if(GlobalData.numPlaces>0)
                    {
                        GlobalData.numPlaces=0;
                        GlobalData.place.clear();
                    }


                    for (int i = 0; i < jsonArray.length(); i++) {
                        JSONObject jo_inside = jsonArray.getJSONObject(i);
                        Log.d("Details-->", jo_inside.getString("Place_name"));
                        Places p1=new Places();
                        p1.Place_id = jo_inside.getInt("Place_id");
                        if(p1.Place_id>0)//some data of place is there then only add it
                        {
                            p1.Place_id = jo_inside.getInt("Place_id");
                            p1.Lat = jo_inside.getString("Lat");

                            p1.Lng = jo_inside.getString("Lng");
                            p1.Place_name = jo_inside.getString("Place_name");
                            GlobalData.place.add(p1);
                            GlobalData.numPlaces++;
                        }//end if
                    }//end for

                } catch (JSONException e) {
                    e.printStackTrace();
                }


            } catch (IOException e) {
                e.printStackTrace();
            }

/*
            //////////////////////////////////////////////////////////////
            // loading data of places read earlier

            httppostreq = new HttpPost("http://cdata.mybluemix.net/Send_places_data");
            try {
                HttpResponse httpresponse = httpclient.execute(httppostreq);

                InputStream stream=httpresponse.getEntity().getContent();
                BufferedReader reader = new BufferedReader(new InputStreamReader(
                        stream, "UTF-8"), 8);
                StringBuilder sb = new StringBuilder();
                String line = null;
                while ((line = reader.readLine()) != null) {
                    sb.append(line + "\n");
                }
                String response2 = sb.toString();
                stream.close();
                //
                //Toast.makeText(cnt, stream.toString(), Toast.LENGTH_SHORT).show();
                Log.d("cloud server","stream from server"+ response2);

                //places are in response string
                try {
                    JSONArray jsonArray = new JSONArray(response2);


                    //clearing already read places in the memory
                    if(GlobalData.Datapoint>0)
                    {
                        GlobalData.Datapoint=0;
                        GlobalData.sensordata.clear();
                    }


                    for (int i = 0; i < jsonArray.length(); i++) {
                        JSONObject jo_inside = jsonArray.getJSONObject(i);
                        if(jo_inside.has("Place_name"))
                        Log.d("Details-data->", jo_inside.getString("Place_name"));

                        SensorData s=new SensorData();
                        if(jo_inside.has("Place_id"))
                            s.Place_id=jo_inside.getString("Place_id");
                        if(jo_inside.has("Place_name"))
                            s.Place_name=jo_inside.getString("Place_name");
                        if(jo_inside.has("Lat"))
                            s.Lat = jo_inside.getString("Lat");
                        if(jo_inside.has("Lng"))
                            s.Lng=jo_inside.getString("Lng");
                        if(jo_inside.has("Year"))
                            s.Year=jo_inside.getString("Year");
                        if(jo_inside.has("Month"))
                            s.Month=jo_inside.getString("Month");
                        if(jo_inside.has("Air_Temperature"))
                            s.Air_Temperature=jo_inside.getString("Air_Temperature");
                        if(jo_inside.has("Water_Temperature"))
                            s.Water_Temperature=jo_inside.getString("Water_Temperature");
                        if(jo_inside.has("DO"))
                            s.DO=jo_inside.getString("DO");
                        if(jo_inside.has("BOD"))
                            s.BOD=jo_inside.getString("BOD");
                        if(jo_inside.has("COD"))
                            s.COD=jo_inside.getString("COD");
                        if(jo_inside.has("pH"))
                            s.pH=jo_inside.getString("pH");
                        if(jo_inside.has("Turbidity"))
                            s.Turbidity=jo_inside.getString("Turbidity");
                        if(jo_inside.has("Conductivity"))
                            s.Conductivity=jo_inside.getString("Conductivity");
                        if(jo_inside.has("TC"))
                            s.TC=jo_inside.getString("TC");
                        if(jo_inside.has("FC"))
                            s.FC=jo_inside.getString("FC");
                        if(jo_inside.has("FS"))
                            s.FS=jo_inside.getString("FS");
                        if(jo_inside.has("Velocity"))
                            s.Velocity=jo_inside.getString("Velocity");
                        if(jo_inside.has("Hardness"))
                            s.Hardness=jo_inside.getString("Hardness");
                        if(jo_inside.has("Alkalinity"))
                            s.Alkalinity=jo_inside.getString("Alkalinity");
                        if(jo_inside.has("Chloride"))
                            s.Chloride=jo_inside.getString("Chloride");
                        if(jo_inside.has("Cadmium"))
                            s.Cadmium=jo_inside.getString("Cadmium");
                        if(jo_inside.has("Chromium"))
                            s.Chromium=jo_inside.getString("Chromium");
                        if(jo_inside.has("Sulphate"))
                            s.Sulphate=jo_inside.getString("Sulphate");
                        if(jo_inside.has("Nickel"))
                            s.Nickel=jo_inside.getString("Nickel");
                        if(jo_inside.has("Iron"))
                            s.Iron=jo_inside.getString("Iron");
                        if(jo_inside.has("Na"))
                            s.Na=jo_inside.getString("Na");

                        GlobalData.sensordata.add(s);
                        GlobalData.Datapoint++;

                    }

                } catch (JSONException e) {
                    e.printStackTrace();
                }


            } catch (IOException e) {
                e.printStackTrace();
            }


            //loading general_limits of different parameters

            httppostreq = new HttpPost("http://cdata.mybluemix.net/Send_limit_general");
            try {
                HttpResponse httpresponse = httpclient.execute(httppostreq);

                InputStream stream=httpresponse.getEntity().getContent();
                BufferedReader reader = new BufferedReader(new InputStreamReader(
                        stream, "UTF-8"), 8);
                StringBuilder sb = new StringBuilder();
                String line = null;
                while ((line = reader.readLine()) != null) {
                    sb.append(line + "\n");
                }
                String response = sb.toString();
                stream.close();
                //
                //Toast.makeText(cnt, stream.toString(), Toast.LENGTH_SHORT).show();
                Log.d("cloud server", "stream from server" + response);

                //places are in response string
                try {
                    JSONArray jsonArray = new JSONArray(response);

                    for (int i = 0; i < jsonArray.length(); i++) {
                        JSONObject jo_inside = jsonArray.getJSONObject(i);
                        if(jo_inside.has("DO_min"))
                        Log.d("Details limits-->", jo_inside.getString("DO_min"));
                        GlobalData.lg=new Limits_general();

                        if(jo_inside.has("Air_Temperature_max"))
                            GlobalData.lg.Air_Temperature_max=jo_inside.getString("Air_Temperature_max");
                        if(jo_inside.has("Water_Temperature_max"))
                            GlobalData.lg.Water_Temperature_max=jo_inside.getString("Water_Temperature_max");
                        if(jo_inside.has("DO_max"))
                            GlobalData.lg.DO_max=jo_inside.getString("DO_max");
                        if(jo_inside.has("BOD_max"))
                            GlobalData.lg.BOD_max=jo_inside.getString("BOD_max");
                        if(jo_inside.has("COD_max"))
                            GlobalData.lg.COD_max=jo_inside.getString("COD_max");
                        if(jo_inside.has("pH_max"))
                            GlobalData.lg.pH_max=jo_inside.getString("pH_max");
                        if(jo_inside.has("Turbidity_max"))
                            GlobalData.lg.Turbidity_max=jo_inside.getString("Turbidity_max");
                        if(jo_inside.has("Conductivity_max"))
                            GlobalData.lg.Conductivity_max=jo_inside.getString("Conductivity_max");
                        if(jo_inside.has("TC_max"))
                            GlobalData.lg.TC_max=jo_inside.getString("TC_max");
                        if(jo_inside.has("FC_max"))
                            GlobalData.lg.FC_max=jo_inside.getString("FC_max");
                        if(jo_inside.has("FS_max"))
                            GlobalData.lg.FS_max=jo_inside.getString("FS_max");
                        if(jo_inside.has("Velocity_max"))
                            GlobalData.lg.Velocity_max=jo_inside.getString("Velocity_max");
                        if(jo_inside.has("Hardness_max"))
                            GlobalData.lg.Hardness_max=jo_inside.getString("Hardness_max");
                        if(jo_inside.has("Alkalinity_max"))
                            GlobalData.lg.Alkalinity_max=jo_inside.getString("Alkalinity_max");
                        if(jo_inside.has("Chloride_max"))
                            GlobalData.lg.Chloride_max=jo_inside.getString("Chloride_max");
                        if(jo_inside.has("Cadmium_max"))
                            GlobalData.lg.Cadmium_max=jo_inside.getString("Cadmium_max");
                        if(jo_inside.has("Chromium_max"))
                            GlobalData.lg.Chromium_max=jo_inside.getString("Chromium_max");
                        if(jo_inside.has("Sulphate_max"))
                            GlobalData.lg.Sulphate_max=jo_inside.getString("Sulphate_max");
                        if(jo_inside.has("Nickel_max"))
                            GlobalData.lg.Nickel_max=jo_inside.getString("Nickel_max");
                        if(jo_inside.has("Iron_max"))
                            GlobalData.lg.Iron_max=jo_inside.getString("Iron_max");
                        if(jo_inside.has("Na_max"))
                            GlobalData.lg.Na_max=jo_inside.getString("Na_max");

                        if(jo_inside.has("Air_Temperature_min"))
                            GlobalData.lg.Air_Temperature_min=jo_inside.getString("Air_Temperature_min");
                        if(jo_inside.has("Water_Temperature_min"))
                            GlobalData.lg.Water_Temperature_min=jo_inside.getString("Water_Temperature_min");
                        if(jo_inside.has("DO_min"))
                            GlobalData.lg.DO_min=jo_inside.getString("DO_min");
                        if(jo_inside.has("BOD_min"))
                            GlobalData.lg.BOD_min=jo_inside.getString("BOD_min");
                        if(jo_inside.has("COD_min"))
                            GlobalData.lg.COD_min=jo_inside.getString("COD_min");
                        if(jo_inside.has("pH_min"))
                            GlobalData.lg.pH_min=jo_inside.getString("pH_min");
                        if(jo_inside.has("Turbidity_min"))
                            GlobalData.lg.Turbidity_min=jo_inside.getString("Turbidity_min");
                        if(jo_inside.has("Conductivity_min"))
                            GlobalData.lg.Conductivity_min=jo_inside.getString("Conductivity_min");
                        if(jo_inside.has("TC_min"))
                            GlobalData.lg.TC_min=jo_inside.getString("TC_min");
                        if(jo_inside.has("FC_min"))
                            GlobalData.lg.FC_min=jo_inside.getString("FC_min");
                        if(jo_inside.has("FS_min"))
                            GlobalData.lg.FS_min=jo_inside.getString("FS_min");
                        if(jo_inside.has("Velocity_min"))
                            GlobalData.lg.Velocity_min=jo_inside.getString("Velocity_min");
                        if(jo_inside.has("Hardness_min"))
                            GlobalData.lg.Hardness_min=jo_inside.getString("Hardness_min");
                        if(jo_inside.has("Alkalinity_min"))
                            GlobalData.lg.Alkalinity_min=jo_inside.getString("Alkalinity_min");
                        if(jo_inside.has("Chloride_min"))
                            GlobalData.lg.Chloride_min=jo_inside.getString("Chloride_min");
                        if(jo_inside.has("Cadmium_min"))
                            GlobalData.lg.Cadmium_min=jo_inside.getString("Cadmium_min");
                        if(jo_inside.has("Chromium_min"))
                            GlobalData.lg.Chromium_min=jo_inside.getString("Chromium_min");
                        if(jo_inside.has("Sulphate_min"))
                            GlobalData.lg.Sulphate_min=jo_inside.getString("Sulphate_min");
                        if(jo_inside.has("Nickel_min"))
                            GlobalData.lg.Nickel_min=jo_inside.getString("Nickel_min");
                        if(jo_inside.has("Iron_min"))
                            GlobalData.lg.Iron_min=jo_inside.getString("Iron_min");
                        if(jo_inside.has("Na_min"))
                            GlobalData.lg.Na_min=jo_inside.getString("Na_min");
                    }

                } catch (JSONException e) {
                    e.printStackTrace();
                }


            } catch (IOException e) {
                e.printStackTrace();
            }
//end loading limits of general parameters
*/


            return totalSize;
        }//end function

        protected void onProgressUpdate(Integer... progress) {
            //setProgressPercent(progress[0]);
        }

        protected void onPostExecute(Long result) {
            // showDialog("Downloaded " + result + " bytes");

           // Intent intent = new Intent(cnt, List_places.class);
            //startActivity(intent);
            setContentView(R.layout.activity_list_places);

            listView = (ListView) findViewById(R.id.list_of_places);
            //LIST OF ARRAY STRINGS WHICH WILL SERVE AS LIST ITEMS
            ArrayList<String> listItems = new ArrayList<String>();
            //DEFINING A STRING ADAPTER WHICH WILL HANDLE THE DATA OF THE LISTVIEW
            ArrayAdapter<String> adapter;

            adapter = new ArrayAdapter<String>(cnt,
                    android.R.layout.simple_list_item_1, android.R.id.text1,
                    listItems);

            // Assign adapter to ListView
            listView.setAdapter(adapter);
            AddListItems(listItems);
            adapter.notifyDataSetChanged();
            // ListView Item Click Listener
            listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {

                @Override
                public void onItemClick(AdapterView<?> parent, View view,
                                        int position, long id) {
                    // ListView Clicked item index
                    int itemPosition = position;
                    // ListView Clicked item value
                    String itemValue = (String) listView.getItemAtPosition(position);
                    // Show Alert
                   // Toast.makeText(cnt,"Position :" + itemPosition + "  ListItem : " + itemValue, Toast.LENGTH_LONG).show();
                    GlobalData.current_marker = itemValue;

                    Places p =GlobalData.place.get(itemPosition);
                    GlobalData.current_Lat=p.Lat;
                    GlobalData.current_Lng=p.Lng;

                    Intent intent = new Intent(getApplicationContext(), PlacesData2.class);
                    startActivity(intent);


                }

            });
        }//end onpost
    }


}
