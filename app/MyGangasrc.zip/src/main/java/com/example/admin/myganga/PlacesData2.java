package com.example.admin.myganga;

import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.Drawable;
import android.os.AsyncTask;
import android.support.v7.app.ActionBarActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.Gravity;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.ScrollView;
import android.widget.TableLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.github.mikephil.charting.charts.BarChart;
import com.github.mikephil.charting.data.BarData;
import com.github.mikephil.charting.data.BarDataSet;
import com.github.mikephil.charting.data.BarEntry;

import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;


public class PlacesData2 extends ActionBarActivity {
    String nodata="No data";
    Context cnt;
    String[] Month_s = {"dummy","Jan", "Feb", "Mar", "Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"};
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //setContentView(R.layout.activity_places_data2);
        cnt=this;
        //read data of the place which is selected

        RelativeLayout layout = new RelativeLayout(this);
        ProgressBar progressBar = new ProgressBar(cnt,null,android.R.attr.progressBarStyleLarge);
        progressBar.setIndeterminate(true);
        progressBar.setVisibility(View.VISIBLE);
        RelativeLayout.LayoutParams params = new RelativeLayout.LayoutParams(100,100);
        params.addRule(RelativeLayout.CENTER_IN_PARENT);
        layout.addView(progressBar,params);
        setContentView(layout);
        DownloadFilesTask dw=new DownloadFilesTask();
        dw.execute();

        //end read data of the place which is selected

    }

    void show_data_layout() {

        //LinearLayout.LayoutParams (int width, int height, float weight)
      //add dynamic layout to show one most recent data reading
       final LinearLayout.LayoutParams Param_full = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.FILL_PARENT, LinearLayout.LayoutParams.FILL_PARENT);

        LinearLayout P_1 = new LinearLayout(cnt);
        P_1.setOrientation(LinearLayout.VERTICAL);
        P_1.setLayoutParams(Param_full);


        LinearLayout.LayoutParams lp_2 = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.FILL_PARENT, 0);
        lp_2.setMargins(5, 5, 5, 5);
        lp_2.weight = 1;
        LinearLayout P_2 = new LinearLayout(cnt);
        P_2.setOrientation(LinearLayout.HORIZONTAL);
        P_2.setLayoutParams(lp_2);
        P_1.addView(P_2);

        //at p2 add  place name details
        P_2.setBackgroundResource(R.drawable.lightblue);
        LinearLayout.LayoutParams lpname = new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.FILL_PARENT);
        lpname.weight=1;
        lpname.setMargins(2, 2, 2, 2);
        TextView pname = new TextView(cnt);
        pname.setText(GlobalData.current_marker);
        pname.setLayoutParams(lpname);
        pname.setTextSize(20);
        pname.setGravity(Gravity.CENTER);
        pname.setTextColor(Color.WHITE);
        P_2.addView(pname);

        //end at p2 place name details



        LinearLayout.LayoutParams lp_3 = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.FILL_PARENT, 0);
        LinearLayout.LayoutParams lsp_3 = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.FILL_PARENT,LinearLayout.LayoutParams.FILL_PARENT );
        lp_3.setMargins(5, 5, 5, 5);
        lp_3.weight = 4;
        ScrollView S_3 = new ScrollView(cnt);
        S_3.setLayoutParams(lp_3);
        LinearLayout P_3 = new LinearLayout(cnt);
        P_3.setOrientation(LinearLayout.HORIZONTAL);
        P_3.setLayoutParams(lsp_3);
        S_3.setScrollbarFadingEnabled(false);
        S_3.addView(P_3);
        P_1.addView(S_3);


        LinearLayout.LayoutParams lp_4 = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.FILL_PARENT, 0);
        lp_4.setMargins(5, 5, 5, 5);
        lp_4.weight = 1;
        LinearLayout P_4 = new LinearLayout(cnt);
        P_4.setOrientation(LinearLayout.VERTICAL);
        P_4.setLayoutParams(lp_4);
        P_1.addView(P_4);

        LinearLayout.LayoutParams lp_5 = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.FILL_PARENT, 0);
        lp_5.setMargins(5, 5, 5, 5);
        lp_5.weight = 1;
        LinearLayout P_5 = new LinearLayout(cnt);
        P_5.setOrientation(LinearLayout.HORIZONTAL);
        P_5.setLayoutParams(lp_5);
        P_1.addView(P_5);

//LinearLayout.LayoutParams (int width, int height, float weight)
        final LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.FILL_PARENT);
        lp.setMargins(5, 5, 5, 5);
        lp.weight = 1;
        LinearLayout P_3a = new LinearLayout(cnt);
        P_3a.setOrientation(LinearLayout.VERTICAL);
        P_3a.setLayoutParams(lp);
        LinearLayout P_3b = new LinearLayout(cnt);
        P_3b.setOrientation(LinearLayout.VERTICAL);
        P_3b.setLayoutParams(lp);
   //     LinearLayout P_3c = new LinearLayout(cnt);
   //    P_3c.setOrientation(LinearLayout.VERTICAL);
   //   P_3c.setLayoutParams(lp);

        P_3.addView(P_3a);
        P_3.addView(P_3b);
    //    P_3.addView(P_3c);

        //LinearLayout.LayoutParams (int width, int height, float weight)
        LinearLayout.LayoutParams Param_row = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.FILL_PARENT, 130);

        Param_row.setMargins(5, 5, 5, 5);

      //  Param_row.gravity= Gravity.CENTER;

        //adding last rows, date, map and places
        {
            LinearLayout.LayoutParams lt_5 = new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.FILL_PARENT);
            lt_5.weight = 1;
            lt_5.setMargins(2,2,2,2);
            final TextView Date = new TextView(cnt);
            Date.setText("Date");
            Date.setLayoutParams(lt_5);
            //pname.setLayoutParams(lpname);
            Date.setTextSize(20);
            Date.setGravity(Gravity.CENTER);
            Date.setTextColor(Color.WHITE);
            Date.setBackgroundResource(R.drawable.lightblue);
            P_5.addView(Date);

            final TextView Place = new TextView(cnt);
            Place.setText("Places");
            Place.setLayoutParams(lt_5);
            //pname.setLayoutParams(lpname);
            Place.setTextSize(20);
            Place.setGravity(Gravity.CENTER);
            Place.setTextColor(Color.WHITE);
            Place.setBackgroundResource(R.drawable.lightblue);
            P_5.addView(Place);


            final TextView Map = new TextView(cnt);
            Map.setText("Map");
            //pname.setLayoutParams(lpname);
            Map.setLayoutParams(lt_5);
            Map.setTextSize(20);
            Map.setGravity(Gravity.CENTER);
            Map.setTextColor(Color.WHITE);
            Map.setBackgroundResource(R.drawable.lightblue);
            P_5.addView(Map);

            Map.setOnClickListener(new View.OnClickListener() {
                public void onClick(View v) {
                    // Perform action on click
                    Intent intent = new Intent(cnt, MapsPlacesActivity.class);
                    startActivity(intent);

                }
            });

            Place.setOnClickListener(new View.OnClickListener() {
                public void onClick(View v) {
                    // Perform action on click
                    Intent intent = new Intent(cnt, List_places.class);
                    startActivity(intent);

                }
            });
        }
        //end adding last rows, date, map and places

        //adding purpose selection button

        final TextView Purpose = new TextView(cnt);
        Purpose.setText("Purpose:" + GlobalData.Purpose);
       //pname.setLayoutParams(lpname);
        Purpose.setTextSize(20);
        Purpose.setGravity(Gravity.CENTER);
        Purpose.setTextColor(Color.WHITE);
        Purpose.setBackgroundResource(R.drawable.lightblue);
        P_4.addView(Purpose);


        Purpose.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {

                ScrollView S_4 = new ScrollView(cnt);


                LinearLayout layout = new LinearLayout(cnt);
                layout.setOrientation(LinearLayout.VERTICAL);
                // layout.setLayoutParams(new LayoutParams(LayoutParams.FILL_PARENT, LayoutParams.WRAP_CONTENT));
                LinearLayout.LayoutParams lparams = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.FILL_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
                LinearLayout.LayoutParams lparams2 = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.FILL_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
                LinearLayout.LayoutParams lparams3 = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.FILL_PARENT, LinearLayout.LayoutParams.FILL_PARENT);
                lparams2.gravity = Gravity.CENTER;
                S_4.setLayoutParams(lparams2);
                //S_4.addView(layout);
                S_4.setScrollbarFadingEnabled(false);
                layout.setLayoutParams(lparams2);

                lparams.setMargins(30, 20, 30, 0);

                Button Irrigation = new Button(cnt);

                Button ALL = new Button(cnt);
               // Button BATHING = new Button(cnt);
                Button Drinking = new Button(cnt);

                Button Dyeing = new Button(cnt);
                Button Pesticides = new Button(cnt);
                Button Power_plants = new Button(cnt);
                Button Pulp_paper = new Button(cnt);
                Button Tannery = new Button(cnt);
                Button Distillery = new Button(cnt);
                Button Sugar = new Button(cnt);
                Button Dairy = new Button(cnt);
                Button Slaughter_house = new Button(cnt);
                Button Beverage = new Button(cnt);

                Irrigation.setLayoutParams(lparams);
                Irrigation.setText("Irrigation");
                Irrigation.setBackgroundResource(R.drawable.roundedbutton);
                ALL.setLayoutParams(lparams);
                ALL.setText("ALL");
                ALL.setBackgroundResource(R.drawable.roundedbutton);
                //BATHING.setLayoutParams(lparams);
                //BATHING.setText("BATHING");
                //BATHING.setBackgroundResource(R.drawable.roundedbutton);
                Drinking.setLayoutParams(lparams);
                Drinking.setText("Drinking");
                Drinking.setBackgroundResource(R.drawable.roundedbutton);

                Dyeing.setLayoutParams(lparams);
                Dyeing.setText("Dyeing");
                Dyeing.setBackgroundResource(R.drawable.roundedbutton);

                Pesticides.setLayoutParams(lparams);
                Pesticides.setText("Pesticides");
                Pesticides.setBackgroundResource(R.drawable.roundedbutton);

                Power_plants.setLayoutParams(lparams);
                Power_plants.setText("Power plants");
                Power_plants.setBackgroundResource(R.drawable.roundedbutton);

                Pulp_paper.setLayoutParams(lparams);
                Pulp_paper.setText("Pulp and paper");
                Pulp_paper.setBackgroundResource(R.drawable.roundedbutton);

                Tannery.setLayoutParams(lparams);
                Tannery.setText("Tannery");
                Tannery.setBackgroundResource(R.drawable.roundedbutton);

                Distillery.setLayoutParams(lparams);
                Distillery.setText("Distillery");
                Distillery.setBackgroundResource(R.drawable.roundedbutton);

                Sugar.setLayoutParams(lparams);
                Sugar.setText("Sugar");
                Sugar.setBackgroundResource(R.drawable.roundedbutton);

                Dairy.setLayoutParams(lparams);
                Dairy.setText("Dairy");
                Dairy.setBackgroundResource(R.drawable.roundedbutton);

                Slaughter_house.setLayoutParams(lparams);
                Slaughter_house.setText("Slaughter house");
                Slaughter_house.setBackgroundResource(R.drawable.roundedbutton);

                Beverage.setLayoutParams(lparams);
                Beverage.setText("Beverage");
                Beverage.setBackgroundResource(R.drawable.roundedbutton);


                //BATHING.setId(10000);
                ALL.setId(101000);
                Drinking.setId(102000);
                Irrigation.setId(103000);

                Dyeing.setId(10400);
                Pesticides.setId(10500);
                Power_plants.setId(10600);
                Pulp_paper.setId(10700);
                Tannery.setId(10800);
                Distillery.setId(10900);
                Sugar.setId(10010);
                Dairy.setId(10020);
                Slaughter_house.setId(10030);
                Beverage.setId(10040);


                layout.addView(ALL);
                layout.addView(Beverage);
                layout.addView(Dairy);
                layout.addView(Distillery);
                layout.addView(Drinking);
               // layout.addView(BATHING);
                layout.addView(Dyeing);
                layout.addView(Irrigation);

                layout.addView(Pesticides);
                layout.addView(Power_plants);
                layout.addView(Pulp_paper);
                layout.addView(Slaughter_house);
                layout.addView(Sugar);
                layout.addView(Tannery);



                S_4.addView(layout);

                layout.setBackgroundResource(R.drawable.female1);
                final Dialog dialog = new Dialog(cnt);
                dialog.setContentView(S_4);
                dialog.setTitle("Select Purpose");

                dialog.show();

                Irrigation.setOnClickListener(new View.OnClickListener() {
                    public void onClick(View v) {

                        // Purpose.setText("Purpose : Irrigation");
                        GlobalData.Purpose = "Irrigation";
                        dialog.hide();
                        show_data_layout();

                    }
                });

                ALL.setOnClickListener(new View.OnClickListener() {
                    public void onClick(View v) {

                       // Purpose.setText("Purpose : All");
                        GlobalData.Purpose="All";
                        dialog.hide();
                        show_data_layout();

                    }
                });

                Drinking.setOnClickListener(new View.OnClickListener() {
                    public void onClick(View v) {

                      //  Purpose.setText("Purpose : Drinking");
                        GlobalData.Purpose="Drinking";
                        dialog.hide();
                        show_data_layout();
                    }
                });

               /* BATHING.setOnClickListener(new View.OnClickListener() {
                    public void onClick(View v) {

                      //  Purpose.setText("Purpose : Bathing");
                        GlobalData.Purpose="Bathing";
                        dialog.hide();
                        show_data_layout();
                    }
                });
                */
                Dyeing.setOnClickListener(new View.OnClickListener() {
                    public void onClick(View v) {

                        //  Purpose.setText("Purpose : Bathing");
                        GlobalData.Purpose="Dyeing";
                        dialog.hide();
                        show_data_layout();
                    }
                });
                Pesticides.setOnClickListener(new View.OnClickListener() {
                    public void onClick(View v) {

                        //  Purpose.setText("Purpose : Bathing");
                        GlobalData.Purpose="Pesticides";
                        dialog.hide();
                        show_data_layout();
                    }
                });
                Power_plants.setOnClickListener(new View.OnClickListener() {
                    public void onClick(View v) {

                        //  Purpose.setText("Purpose : Bathing");
                        GlobalData.Purpose = "Power plants";
                        dialog.hide();
                        show_data_layout();
                    }
                });
                Pulp_paper.setOnClickListener(new View.OnClickListener() {
                    public void onClick(View v) {

                        //  Purpose.setText("Purpose : Bathing");
                        GlobalData.Purpose = "Pulp and paper";
                        dialog.hide();
                        show_data_layout();
                    }
                });
                Tannery.setOnClickListener(new View.OnClickListener() {
                    public void onClick(View v) {

                        //  Purpose.setText("Purpose : Bathing");
                        GlobalData.Purpose = "Tannery";
                        dialog.hide();
                        show_data_layout();
                    }
                });
                Distillery.setOnClickListener(new View.OnClickListener() {
                    public void onClick(View v) {

                        //  Purpose.setText("Purpose : Bathing");
                        GlobalData.Purpose="Distillery";
                        dialog.hide();
                        show_data_layout();
                    }
                });
                Sugar.setOnClickListener(new View.OnClickListener() {
                    public void onClick(View v) {

                        //  Purpose.setText("Purpose : Bathing");
                        GlobalData.Purpose="Sugar";
                        dialog.hide();
                        show_data_layout();
                    }
                });

                Dairy.setOnClickListener(new View.OnClickListener() {
                    public void onClick(View v) {

                        //  Purpose.setText("Purpose : Bathing");
                        GlobalData.Purpose="Dairy";
                        dialog.hide();
                        show_data_layout();
                    }
                });
                Slaughter_house.setOnClickListener(new View.OnClickListener() {
                    public void onClick(View v) {

                        //  Purpose.setText("Purpose : Bathing");
                        GlobalData.Purpose = "Slaughter house";
                        dialog.hide();
                        show_data_layout();
                    }
                });
                Beverage.setOnClickListener(new View.OnClickListener() {
                    public void onClick(View v) {

                        //  Purpose.setText("Purpose : Bathing");
                        GlobalData.Purpose = "Beverage";
                        dialog.hide();
                        show_data_layout();
                    }
                });

            }
        });//end select_purpose.onclick


        //end adding purpose selection button





        //take the first recent data point from global data

        if(GlobalData.sensordata.size()>0)
        {
          SensorData s=GlobalData.sensordata.get(0);//take the first, it will be most recent one


            //add time to p2
            TextView stime = new TextView(cnt);
            if(s.source.equals("live_sensor_data"))
            stime.setText(s.date+"\n("+s.time+")");

            else if(s.source.equals("Historical"))
                stime.setText(s.Year + "\n(" + Month_s[Integer.parseInt(s.Month)] + ")");

            stime.setLayoutParams(lpname);
            stime.setTextSize(20);
            stime.setGravity(Gravity.CENTER);
            stime.setTextColor(Color.WHITE);
            P_2.addView(stime);



         if(!s.DO.isEmpty())
         {
             TextView tv = new TextView(cnt);
             if(!s.DO.equals("-1.0"))
             tv.setText("Do\n" + s.DO);
             else
                 tv.setText("Do\n" + nodata);


             tv.setLayoutParams(Param_row);
             tv.setTextSize(20);
             //tv.setBackgroundResource(R.drawable.lightblue);
             if(GlobalData.Purpose.equals("Drinking"))
                 tv.setBackgroundColor(Color.parseColor("#FFDAB9"));
             else
                 tv.setBackgroundColor(Color.parseColor("#DAE5E8"));
             tv.setGravity(Gravity.CENTER);

             tv.setOnClickListener(new View.OnClickListener() {
                 @Override
                 public void onClick(View v)
                 {
                     ArrayList<BarEntry> entries = new ArrayList<>();
                     ArrayList<String> labels = new ArrayList<String>();
                     for(int i=0;i<GlobalData.sensordata.size();i++)
                     {
                         Double dObj = new Double(GlobalData.sensordata.get(i).DO);
                         float a=dObj.floatValue();
                         entries.add(new BarEntry(a,i));
                     }
                     BarDataSet dataset = new BarDataSet(entries, "Dissolved Oxygen");
                     for(int i=0;i<GlobalData.sensordata.size();i++)
                     {
                         if(GlobalData.sensordata.get(i).source.equals("live_sensor_data"))
                         labels.add(GlobalData.sensordata.get(i).date+"\n"+GlobalData.sensordata.get(i).time);

                         if(GlobalData.sensordata.get(i).source.equals("Historical"))
                             labels.add(GlobalData.sensordata.get(i).Year+"\n"+Month_s[Integer.parseInt(GlobalData.sensordata.get(i).Month)]);
                     }

                     setContentView(R.layout.layout_graph);
                     BarChart chart = (BarChart) findViewById(R.id.chart);
                     BarData data = new BarData(labels, dataset);
                     chart.setData(data);
                     chart.setDescription("Do Variation With Time");
                     chart.setVisibleXRangeMaximum(4);
                     chart.setVisibleXRangeMinimum(2);
                     chart.moveViewToX(-1);
                    // Toast.makeText(cnt, "Datapoints" + GlobalData.sensordata.size(), Toast.LENGTH_SHORT).show();

                     Button close_chart=(Button) findViewById(R.id.close_chart);

                     close_chart.setOnClickListener(new View.OnClickListener() {
                         public void onClick(View v) {

                             show_data_layout();
                         }
                     });

                 }
             });
             P_3a.addView(tv);
         }//end if(s.Do!=-1)

            if(!s.pH.isEmpty())
            {
                TextView tv = new TextView(cnt);
                tv.setText("pH\n" + s.pH);
                tv.setLayoutParams(Param_row);
                tv.setTextSize(20);
                //tv.setBackgroundResource(R.drawable.lightblue);
                if(!GlobalData.Purpose.equals("All"))
                    tv.setBackgroundColor(Color.parseColor("#FFDAB9"));
                else
                    tv.setBackgroundColor(Color.parseColor("#DAE5E8"));

                //tv.setBackgroundColor(Color.parseColor("#DAE5E8"));
                tv.setGravity(Gravity.CENTER);

                tv.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v)
                    {
                        ArrayList<BarEntry> entries = new ArrayList<>();
                        ArrayList<String> labels = new ArrayList<String>();
                        for(int i=0;i<GlobalData.sensordata.size();i++)
                        {
                            Double dObj = new Double(GlobalData.sensordata.get(i).pH);
                            float a=dObj.floatValue();
                            entries.add(new BarEntry(a,i));
                        }
                        BarDataSet dataset = new BarDataSet(entries, "pH");
                        for(int i=0;i<GlobalData.sensordata.size();i++)
                        {
                            if(GlobalData.sensordata.get(i).source.equals("live_sensor_data"))
                                labels.add(GlobalData.sensordata.get(i).date+"\n"+GlobalData.sensordata.get(i).time);

                            if(GlobalData.sensordata.get(i).source.equals("Historical"))
                                labels.add(GlobalData.sensordata.get(i).Year+"\n"+Month_s[Integer.parseInt(GlobalData.sensordata.get(i).Month)]);
                        }

                        setContentView(R.layout.layout_graph);
                        BarChart chart = (BarChart) findViewById(R.id.chart);
                        BarData data = new BarData(labels, dataset);
                        chart.setData(data);
                        chart.setDescription("pH Variation With Time");
                        chart.setVisibleXRangeMaximum(4);
                        chart.setVisibleXRangeMinimum(2);
                        chart.moveViewToX(-1);
                     //   Toast.makeText(cnt, "Datapoints" + GlobalData.sensordata.size(), Toast.LENGTH_SHORT).show();

                        Button close_chart=(Button) findViewById(R.id.close_chart);

                        close_chart.setOnClickListener(new View.OnClickListener() {
                            public void onClick(View v) {

                                show_data_layout();
                            }
                        });

                    }
                });
                P_3a.addView(tv);
            }//end if(s.Do!=-1)

            if(!s.Turbidity.isEmpty())
            {
                TextView tv = new TextView(cnt);
                tv.setText("Turbidity\n" + s.Turbidity);
                tv.setLayoutParams(Param_row);
                tv.setTextSize(20);
                //tv.setBackgroundResource(R.drawable.lightblue);
                tv.setBackgroundColor(Color.parseColor("#DAE5E8"));
                tv.setGravity(Gravity.CENTER);

                tv.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v)
                    {
                        ArrayList<BarEntry> entries = new ArrayList<>();
                        ArrayList<String> labels = new ArrayList<String>();
                        for(int i=0;i<GlobalData.sensordata.size();i++)
                        {
                            Double dObj = new Double(GlobalData.sensordata.get(i).Turbidity);
                            float a=dObj.floatValue();
                            entries.add(new BarEntry(a,i));
                        }
                        BarDataSet dataset = new BarDataSet(entries, "Turbidity");
                        for(int i=0;i<GlobalData.sensordata.size();i++)
                        {
                            if(GlobalData.sensordata.get(i).source.equals("live_sensor_data"))
                                labels.add(GlobalData.sensordata.get(i).date+"\n"+GlobalData.sensordata.get(i).time);

                            if(GlobalData.sensordata.get(i).source.equals("Historical"))
                                labels.add(GlobalData.sensordata.get(i).Year+"\n"+Month_s[Integer.parseInt(GlobalData.sensordata.get(i).Month)]);
                        }

                        setContentView(R.layout.layout_graph);
                        BarChart chart = (BarChart) findViewById(R.id.chart);
                        BarData data = new BarData(labels, dataset);
                        chart.setData(data);
                        chart.setDescription("Turbidity Variation With Time");
                        chart.setVisibleXRangeMaximum(4);
                        chart.setVisibleXRangeMinimum(2);
                        chart.moveViewToX(-1);
                     //   Toast.makeText(cnt, "Datapoints" + GlobalData.sensordata.size(), Toast.LENGTH_SHORT).show();

                        Button close_chart=(Button) findViewById(R.id.close_chart);

                        close_chart.setOnClickListener(new View.OnClickListener() {
                            public void onClick(View v) {

                                show_data_layout();
                            }
                        });

                    }
                });
                P_3a.addView(tv);
            }//end if(s.Do!=-1)


            if(!s.Conductivity.isEmpty())
            {
                TextView tv = new TextView(cnt);
                tv.setText("Conductivity\n" + s.Conductivity);
                tv.setLayoutParams(Param_row);
                tv.setTextSize(20);
                //tv.setBackgroundResource(R.drawable.lightblue);
                tv.setBackgroundColor(Color.parseColor("#DAE5E8"));
                tv.setGravity(Gravity.CENTER);

                tv.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v)
                    {
                        ArrayList<BarEntry> entries = new ArrayList<>();
                        ArrayList<String> labels = new ArrayList<String>();
                        for(int i=0;i<GlobalData.sensordata.size();i++)
                        {
                            Double dObj = new Double(GlobalData.sensordata.get(i).Conductivity);
                            float a=dObj.floatValue();
                            entries.add(new BarEntry(a,i));
                        }
                        BarDataSet dataset = new BarDataSet(entries, "Conductivity");
                        for(int i=0;i<GlobalData.sensordata.size();i++)
                        {
                            if(GlobalData.sensordata.get(i).source.equals("live_sensor_data"))
                                labels.add(GlobalData.sensordata.get(i).date+"\n"+GlobalData.sensordata.get(i).time);

                            if(GlobalData.sensordata.get(i).source.equals("Historical"))
                                labels.add(GlobalData.sensordata.get(i).Year+"\n"+Month_s[Integer.parseInt(GlobalData.sensordata.get(i).Month)]);
                        }

                        setContentView(R.layout.layout_graph);
                        BarChart chart = (BarChart) findViewById(R.id.chart);
                        BarData data = new BarData(labels, dataset);
                        chart.setData(data);
                        chart.setDescription("Conductivity Variation With Time");
                        chart.setVisibleXRangeMaximum(4);
                        chart.setVisibleXRangeMinimum(2);
                        chart.moveViewToX(-1);
                     //   Toast.makeText(cnt, "Datapoints" + GlobalData.sensordata.size(), Toast.LENGTH_SHORT).show();

                        Button close_chart=(Button) findViewById(R.id.close_chart);

                        close_chart.setOnClickListener(new View.OnClickListener() {
                            public void onClick(View v) {

                                show_data_layout();
                            }
                        });

                    }
                });
                P_3a.addView(tv);
            }//end if(s.Do!=-1)


            if(!s.TC.isEmpty())
            {
                TextView tv = new TextView(cnt);
                if(!s.TC.equals("-1.0"))
                    tv.setText("TC\n" + s.TC);
                else
                    tv.setText("TC\n" + nodata);


                tv.setLayoutParams(Param_row);
                tv.setTextSize(20);
                //tv.setBackgroundResource(R.drawable.lightblue);
                tv.setBackgroundColor(Color.parseColor("#DAE5E8"));
                tv.setGravity(Gravity.CENTER);

                tv.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v)
                    {
                        ArrayList<BarEntry> entries = new ArrayList<>();
                        ArrayList<String> labels = new ArrayList<String>();
                        for(int i=0;i<GlobalData.sensordata.size();i++)
                        {
                            Double dObj = new Double(GlobalData.sensordata.get(i).TC);
                            float a=dObj.floatValue()/1000;
                            if(!GlobalData.sensordata.get(i).TC.equals("-1.0"))
                            entries.add(new BarEntry(a,i));
                        }
                        BarDataSet dataset = new BarDataSet(entries, "TC*1000");
                        for(int i=0;i<GlobalData.sensordata.size();i++)
                        {
                            if(GlobalData.sensordata.get(i).source.equals("live_sensor_data") &&!GlobalData.sensordata.get(i).TC.equals("-1.0") )
                                labels.add(GlobalData.sensordata.get(i).date+"\n"+GlobalData.sensordata.get(i).time);

                            if(GlobalData.sensordata.get(i).source.equals("Historical")&&!GlobalData.sensordata.get(i).TC.equals("-1.0"))
                                labels.add(GlobalData.sensordata.get(i).Year+"\n"+Month_s[Integer.parseInt(GlobalData.sensordata.get(i).Month)]);
                        }

                        setContentView(R.layout.layout_graph);
                        BarChart chart = (BarChart) findViewById(R.id.chart);
                        BarData data = new BarData(labels, dataset);
                        chart.setData(data);
                        chart.setDescription("TC*1000 Variation With Time");
                        chart.setVisibleXRangeMaximum(4);
                        chart.setVisibleXRangeMinimum(2);
                        chart.moveViewToX(-1);
                      //  Toast.makeText(cnt, "Datapoints" + GlobalData.sensordata.size(), Toast.LENGTH_SHORT).show();

                        Button close_chart=(Button) findViewById(R.id.close_chart);

                        close_chart.setOnClickListener(new View.OnClickListener() {
                            public void onClick(View v) {

                                show_data_layout();
                            }
                        });

                    }
                });
                P_3b.addView(tv);
            }//end if(s.Do!=-1)




            if(!s.Water_Temperature.isEmpty())
            {
                TextView tv = new TextView(cnt);
                if(!s.Water_Temperature.equals("-1.0"))
                    tv.setText("Water Temp\n" + s.Water_Temperature);
                else
                    tv.setText("Water Temp\n" + nodata);

              //  tv.setText("Water Temp\n" + s.Water_Temperature);
                tv.setLayoutParams(Param_row);
                tv.setTextSize(20);
                //tv.setBackgroundResource(R.drawable.lightblue);
                if(GlobalData.Purpose.equals("Power plants"))
                    tv.setBackgroundColor(Color.parseColor("#FFDAB9"));
                else
                    tv.setBackgroundColor(Color.parseColor("#DAE5E8"));


                //tv.setBackgroundColor(Color.parseColor("#DAE5E8"));
                tv.setGravity(Gravity.CENTER);

                tv.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v)
                    {
                        ArrayList<BarEntry> entries = new ArrayList<>();
                        ArrayList<String> labels = new ArrayList<String>();
                        for(int i=0;i<GlobalData.sensordata.size();i++)
                        {
                            Double dObj = new Double(GlobalData.sensordata.get(i).Water_Temperature);
                            float a=dObj.floatValue();
                            if(!GlobalData.sensordata.get(i).Water_Temperature.equals("-1.0"))
                            entries.add(new BarEntry(a,i));
                        }
                        BarDataSet dataset = new BarDataSet(entries, "Water_Temperature");
                        for(int i=0;i<GlobalData.sensordata.size();i++)
                        {
                            if(GlobalData.sensordata.get(i).source.equals("live_sensor_data") &&!GlobalData.sensordata.get(i).Water_Temperature.equals("-1.0"))
                                labels.add(GlobalData.sensordata.get(i).date+"\n"+GlobalData.sensordata.get(i).time);

                            if(GlobalData.sensordata.get(i).source.equals("Historical") &&!GlobalData.sensordata.get(i).Water_Temperature.equals("-1.0"))
                                labels.add(GlobalData.sensordata.get(i).Year+"\n"+Month_s[Integer.parseInt(GlobalData.sensordata.get(i).Month)]);
                        }

                        setContentView(R.layout.layout_graph);
                        BarChart chart = (BarChart) findViewById(R.id.chart);
                        BarData data = new BarData(labels, dataset);
                        chart.setData(data);
                        chart.setDescription("Water_Temperature Variation With Time");
                        chart.setVisibleXRangeMaximum(4);
                        chart.setVisibleXRangeMinimum(2);
                        chart.moveViewToX(-1);
                       // Toast.makeText(cnt, "Datapoints" + GlobalData.sensordata.size(), Toast.LENGTH_SHORT).show();

                        Button close_chart=(Button) findViewById(R.id.close_chart);

                        close_chart.setOnClickListener(new View.OnClickListener() {
                            public void onClick(View v) {

                                show_data_layout();
                            }
                        });

                    }
                });
                P_3b.addView(tv);
            }//end if(s.Do!=-1)

            if(!s.TDS.isEmpty())//.......................
            {
                TextView tv = new TextView(cnt);
                if(!s.TDS.equals("-1.0"))
                    tv.setText("TDS\n" + s.TDS);
                else
                    tv.setText("TDS\n" + nodata);

                //tv.setText("TDS\n" + s.TDS);//.......................
                tv.setLayoutParams(Param_row);
                tv.setTextSize(20);
                //tv.setBackgroundResource(R.drawable.lightblue);
                tv.setBackgroundColor(Color.parseColor("#DAE5E8"));
                tv.setGravity(Gravity.CENTER);

                tv.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v)
                    {
                        ArrayList<BarEntry> entries = new ArrayList<>();
                        ArrayList<String> labels = new ArrayList<String>();
                        for(int i=0;i<GlobalData.sensordata.size();i++)
                        {
                            Double dObj = new Double(GlobalData.sensordata.get(i).TDS);//.......................
                            float a=dObj.floatValue();
                            if(!GlobalData.sensordata.get(i).TDS.equals("-1.0"))
                            entries.add(new BarEntry(a,i));
                        }
                        BarDataSet dataset = new BarDataSet(entries, "TDS");//.......................
                        for(int i=0;i<GlobalData.sensordata.size();i++)
                        {
                            if(GlobalData.sensordata.get(i).source.equals("live_sensor_data")&&!GlobalData.sensordata.get(i).TDS.equals("-1.0"))
                                labels.add(GlobalData.sensordata.get(i).date+"\n"+GlobalData.sensordata.get(i).time);

                            if(GlobalData.sensordata.get(i).source.equals("Historical") && !GlobalData.sensordata.get(i).TDS.equals("-1.0"))
                                labels.add(GlobalData.sensordata.get(i).Year+"\n"+Month_s[Integer.parseInt(GlobalData.sensordata.get(i).Month)]);
                        }

                        setContentView(R.layout.layout_graph);
                        BarChart chart = (BarChart) findViewById(R.id.chart);
                        BarData data = new BarData(labels, dataset);
                        chart.setData(data);
                        chart.setDescription("TDS Variation With Time");//.......................
                        chart.setVisibleXRangeMaximum(4);
                        chart.setVisibleXRangeMinimum(2);
                        chart.moveViewToX(-1);
                   //     Toast.makeText(cnt, "Datapoints" + GlobalData.sensordata.size(), Toast.LENGTH_SHORT).show();

                        Button close_chart=(Button) findViewById(R.id.close_chart);

                        close_chart.setOnClickListener(new View.OnClickListener() {
                            public void onClick(View v) {

                                show_data_layout();
                            }
                        });

                    }
                });
                P_3b.addView(tv);
            }//end if(s.Do!=-1)

            if(!s.Air_Temperature.isEmpty())
            {

                TextView tv = new TextView(cnt);
               if(!s.Air_Temperature.equals("-1.0"))
                tv.setText("Air Temp\n" + s.Air_Temperature);
                else
                   tv.setText("Air Temp\n" + nodata);

                tv.setLayoutParams(Param_row);
                tv.setTextSize(20);
                //tv.setBackgroundResource(R.drawable.lightblue);
                tv.setBackgroundColor(Color.parseColor("#DAE5E8"));
                tv.setGravity(Gravity.CENTER);

                tv.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v)
                    {
                        ArrayList<BarEntry> entries = new ArrayList<>();
                        ArrayList<String> labels = new ArrayList<String>();
                        for(int i=0;i<GlobalData.sensordata.size();i++)
                        {
                            Double dObj = new Double(GlobalData.sensordata.get(i).Air_Temperature);
                            float a=dObj.floatValue();
                            if(!GlobalData.sensordata.get(i).Air_Temperature.equals("-1.0"))
                            entries.add(new BarEntry(a,i));
                        }
                        BarDataSet dataset = new BarDataSet(entries, "Air_Temperature");
                        for(int i=0;i<GlobalData.sensordata.size();i++)
                        {
                            if(GlobalData.sensordata.get(i).source.equals("live_sensor_data") && !GlobalData.sensordata.get(i).Air_Temperature.equals("-1.0"))
                                labels.add(GlobalData.sensordata.get(i).date+"\n"+GlobalData.sensordata.get(i).time);

                            if(GlobalData.sensordata.get(i).source.equals("Historical") && !GlobalData.sensordata.get(i).Air_Temperature.equals("-1.0"))
                                labels.add(GlobalData.sensordata.get(i).Year+"\n"+Month_s[Integer.parseInt(GlobalData.sensordata.get(i).Month)]);
                        }

                        setContentView(R.layout.layout_graph);
                        BarChart chart = (BarChart) findViewById(R.id.chart);
                        BarData data = new BarData(labels, dataset);
                        chart.setData(data);
                        chart.setDescription("Air_Temperature Variation With Time");
                        chart.setVisibleXRangeMaximum(4);
                        chart.setVisibleXRangeMinimum(2);
                        chart.moveViewToX(-1);
        //                Toast.makeText(cnt, "Datapoints" + GlobalData.sensordata.size(), Toast.LENGTH_SHORT).show();

                        Button close_chart=(Button) findViewById(R.id.close_chart);

                        close_chart.setOnClickListener(new View.OnClickListener() {
                            public void onClick(View v) {

                                show_data_layout();
                            }
                        });

                    }
                });
                P_3b.addView(tv);
            }//end if(s.Do!=-1)


            if(!s.FC.isEmpty())
            {
                TextView tv = new TextView(cnt);
                if(!s.FC.equals("-1.0"))
                    tv.setText("FC\n" + s.FC);
                else
                    tv.setText("FC\n" + nodata);

                //tv.setText("FC\n" + s.FC);
                tv.setLayoutParams(Param_row);
                tv.setTextSize(20);
                //tv.setBackgroundResource(R.drawable.lightblue);
                if(GlobalData.Purpose.equals("Drinking"))
                    tv.setBackgroundColor(Color.parseColor("#FFDAB9"));
                else
                    tv.setBackgroundColor(Color.parseColor("#DAE5E8"));

                //tv.setBackgroundColor(Color.parseColor("#DAE5E8"));
                tv.setGravity(Gravity.CENTER);

                tv.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v)
                    {
                        ArrayList<BarEntry> entries = new ArrayList<>();
                        ArrayList<String> labels = new ArrayList<String>();
                        for(int i=0;i<GlobalData.sensordata.size();i++)
                        {
                            Double dObj = new Double(GlobalData.sensordata.get(i).FC);
                            float a=dObj.floatValue();
                            if(!GlobalData.sensordata.get(i).FC.equals("-1.0"))
                            entries.add(new BarEntry(a,i));
                        }
                        BarDataSet dataset = new BarDataSet(entries, "FC");
                        for(int i=0;i<GlobalData.sensordata.size();i++)
                        {
                            if(GlobalData.sensordata.get(i).source.equals("live_sensor_data") && !GlobalData.sensordata.get(i).FC.equals("-1.0"))
                                labels.add(GlobalData.sensordata.get(i).date+"\n"+GlobalData.sensordata.get(i).time);

                            if(GlobalData.sensordata.get(i).source.equals("Historical") && !GlobalData.sensordata.get(i).FC.equals("-1.0"))
                                labels.add(GlobalData.sensordata.get(i).Year+"\n"+Month_s[Integer.parseInt(GlobalData.sensordata.get(i).Month)]);
                        }

                        setContentView(R.layout.layout_graph);
                        BarChart chart = (BarChart) findViewById(R.id.chart);
                        BarData data = new BarData(labels, dataset);
                        chart.setData(data);
                        chart.setDescription("FC Variation With Time");
                        chart.setVisibleXRangeMaximum(4);
                        chart.setVisibleXRangeMinimum(2);
                        chart.moveViewToX(-1);
                        //Toast.makeText(cnt, "Datapoints" + GlobalData.sensordata.size(), Toast.LENGTH_SHORT).show();

                        Button close_chart=(Button) findViewById(R.id.close_chart);

                        close_chart.setOnClickListener(new View.OnClickListener() {
                            public void onClick(View v) {

                                show_data_layout();
                            }
                        });

                    }
                });
                P_3b.addView(tv);
            }//end if(s.Do!=-1)


            if(!s.FS.isEmpty())
            {
                TextView tv = new TextView(cnt);
                if(!s.FS.equals("-1.0"))
                    tv.setText("FS\n" + s.FS);
                else
                    tv.setText("FS\n" + nodata);

                //tv.setText("FS\n" + s.FS);
                tv.setLayoutParams(Param_row);
                tv.setTextSize(20);
                //tv.setBackgroundResource(R.drawable.lightblue);
                tv.setBackgroundColor(Color.parseColor("#DAE5E8"));
                tv.setGravity(Gravity.CENTER);

                tv.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v)
                    {
                        ArrayList<BarEntry> entries = new ArrayList<>();
                        ArrayList<String> labels = new ArrayList<String>();
                        for(int i=0;i<GlobalData.sensordata.size();i++)
                        {
                            Double dObj = new Double(GlobalData.sensordata.get(i).FS);
                            float a=dObj.floatValue();
                            if(!GlobalData.sensordata.get(i).FS.equals("-1.0"))
                            entries.add(new BarEntry(a,i));
                        }
                        BarDataSet dataset = new BarDataSet(entries, "FS");
                        for(int i=0;i<GlobalData.sensordata.size();i++)
                        {
                            if(GlobalData.sensordata.get(i).source.equals("live_sensor_data") && !GlobalData.sensordata.get(i).FS.equals("-1.0"))
                                labels.add(GlobalData.sensordata.get(i).date+"\n"+GlobalData.sensordata.get(i).time);

                            if(GlobalData.sensordata.get(i).source.equals("Historical") && !GlobalData.sensordata.get(i).FS.equals("-1.0"))
                                labels.add(GlobalData.sensordata.get(i).Year+"\n"+Month_s[Integer.parseInt(GlobalData.sensordata.get(i).Month)]);
                        }

                        setContentView(R.layout.layout_graph);
                        BarChart chart = (BarChart) findViewById(R.id.chart);
                        BarData data = new BarData(labels, dataset);
                        chart.setData(data);
                        chart.setDescription("FS Variation With Time");
                        chart.setVisibleXRangeMaximum(4);
                        chart.setVisibleXRangeMinimum(2);
                        chart.moveViewToX(-1);
                       // Toast.makeText(cnt, "Datapoints" + GlobalData.sensordata.size(), Toast.LENGTH_SHORT).show();

                        Button close_chart=(Button) findViewById(R.id.close_chart);

                        close_chart.setOnClickListener(new View.OnClickListener() {
                            public void onClick(View v) {

                                show_data_layout();
                            }
                        });

                    }
                });
                P_3b.addView(tv);
            }//end if(s.Do!=-1)


            if(!s.Velocity.isEmpty())
            {
                TextView tv = new TextView(cnt);

                if(!s.Velocity.equals("-1.0"))
                    tv.setText("Velocity\n" + s.Velocity);
                else
                    tv.setText("Velocity\n" + nodata);

                //tv.setText("Velocity\n" + s.Velocity);
                tv.setLayoutParams(Param_row);
                tv.setTextSize(20);
                //tv.setBackgroundResource(R.drawable.lightblue);

                //dist, sugar, Dairy, sla,bev,Pulp,Tannery
                if(GlobalData.Purpose.equals("Distillery")||GlobalData.Purpose.equals("Sugar")||GlobalData.Purpose.equals("Dairy")||GlobalData.Purpose.equals("Slaughter house")||GlobalData.Purpose.equals("Beverage")||GlobalData.Purpose.equals("Pulp and paper")||GlobalData.Purpose.equals("Tannery"))
                    tv.setBackgroundColor(Color.parseColor("#FFDAB9"));
                else
                    tv.setBackgroundColor(Color.parseColor("#DAE5E8"));


                //tv.setBackgroundColor(Color.parseColor("#DAE5E8"));
                tv.setGravity(Gravity.CENTER);

                tv.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v)
                    {
                        ArrayList<BarEntry> entries = new ArrayList<>();
                        ArrayList<String> labels = new ArrayList<String>();
                        for(int i=0;i<GlobalData.sensordata.size();i++)
                        {
                            Double dObj = new Double(GlobalData.sensordata.get(i).Velocity);
                            float a=dObj.floatValue();

                            if(!GlobalData.sensordata.get(i).Velocity.equals("-1.0"))
                                entries.add(new BarEntry(a,i));
                        }
                        BarDataSet dataset = new BarDataSet(entries, "Velocity");
                        for(int i=0;i<GlobalData.sensordata.size();i++)
                        {
                            if(GlobalData.sensordata.get(i).source.equals("live_sensor_data") && !GlobalData.sensordata.get(i).Velocity.equals("-1.0"))
                                labels.add(GlobalData.sensordata.get(i).date+"\n"+GlobalData.sensordata.get(i).time);

                            if(GlobalData.sensordata.get(i).source.equals("Historical") && !GlobalData.sensordata.get(i).Velocity.equals("-1.0"))
                                labels.add(GlobalData.sensordata.get(i).Year+"\n"+Month_s[Integer.parseInt(GlobalData.sensordata.get(i).Month)]);
                        }

                        setContentView(R.layout.layout_graph);
                        BarChart chart = (BarChart) findViewById(R.id.chart);
                        BarData data = new BarData(labels, dataset);
                        chart.setData(data);
                        chart.setDescription("Velocity Variation With Time");
                        chart.setVisibleXRangeMaximum(4);
                        chart.setVisibleXRangeMinimum(2);
                        chart.moveViewToX(-1);
                        //Toast.makeText(cnt, "Datapoints" + GlobalData.sensordata.size(), Toast.LENGTH_SHORT).show();

                        Button close_chart=(Button) findViewById(R.id.close_chart);

                        close_chart.setOnClickListener(new View.OnClickListener() {
                            public void onClick(View v) {

                                show_data_layout();
                            }
                        });

                    }
                });
                P_3b.addView(tv);
            }//end if(s.Do!=-1)


            if(!s.Hardness.isEmpty())//.......................
            {
                TextView tv = new TextView(cnt);
                if(!s.Hardness.equals("-1.0"))
                    tv.setText("Hardness\n" + s.Hardness);
                else
                    tv.setText("Hardness\n" + nodata);

              //  tv.setText("Hardness\n" + s.Hardness);//.......................
                tv.setLayoutParams(Param_row);
                tv.setTextSize(20);
                //tv.setBackgroundResource(R.drawable.lightblue);
                tv.setBackgroundColor(Color.parseColor("#DAE5E8"));
                tv.setGravity(Gravity.CENTER);

                tv.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v)
                    {
                        ArrayList<BarEntry> entries = new ArrayList<>();
                        ArrayList<String> labels = new ArrayList<String>();
                        for(int i=0;i<GlobalData.sensordata.size();i++)
                        {
                            Double dObj = new Double(GlobalData.sensordata.get(i).Hardness);//.......................
                            float a=dObj.floatValue();
                            if(!GlobalData.sensordata.get(i).Hardness.equals("-1.0"))
                            entries.add(new BarEntry(a,i));
                        }
                        BarDataSet dataset = new BarDataSet(entries, "Hardness");//.......................
                        for(int i=0;i<GlobalData.sensordata.size();i++)
                        {
                            if(GlobalData.sensordata.get(i).source.equals("live_sensor_data") &&!GlobalData.sensordata.get(i).Hardness.equals("-1.0"))//..............
                                labels.add(GlobalData.sensordata.get(i).date+"\n"+GlobalData.sensordata.get(i).time);

                            if(GlobalData.sensordata.get(i).source.equals("Historical") && !GlobalData.sensordata.get(i).Hardness.equals("-1.0"))//...............
                                labels.add(GlobalData.sensordata.get(i).Year+"\n"+Month_s[Integer.parseInt(GlobalData.sensordata.get(i).Month)]);
                        }

                        setContentView(R.layout.layout_graph);
                        BarChart chart = (BarChart) findViewById(R.id.chart);
                        BarData data = new BarData(labels, dataset);
                        chart.setData(data);
                        chart.setDescription("Hardness Variation With Time");//.......................
                        chart.setVisibleXRangeMaximum(4);
                        chart.setVisibleXRangeMinimum(2);
                        chart.moveViewToX(-1);
                    //    Toast.makeText(cnt, "Datapoints" + GlobalData.sensordata.size(), Toast.LENGTH_SHORT).show();

                        Button close_chart=(Button) findViewById(R.id.close_chart);

                        close_chart.setOnClickListener(new View.OnClickListener() {
                            public void onClick(View v) {

                                show_data_layout();
                            }
                        });

                    }
                });
                P_3b.addView(tv);
            }//end if(s.Do!=-1)

            if(!s.Alkalinity.isEmpty())//.......................
            {
                TextView tv = new TextView(cnt);
                if(!s.Alkalinity.equals("-1.0"))
                    tv.setText("Alkalinity\n" + s.Alkalinity);
                else
                    tv.setText("Alkalinity\n" + nodata);

                //tv.setText("Alkalinity\n" + s.Alkalinity);//.......................
                tv.setLayoutParams(Param_row);
                tv.setTextSize(20);
                //tv.setBackgroundResource(R.drawable.lightblue);
                tv.setBackgroundColor(Color.parseColor("#DAE5E8"));
                tv.setGravity(Gravity.CENTER);

                tv.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v)
                    {
                        ArrayList<BarEntry> entries = new ArrayList<>();
                        ArrayList<String> labels = new ArrayList<String>();
                        for(int i=0;i<GlobalData.sensordata.size();i++)
                        {
                            Double dObj = new Double(GlobalData.sensordata.get(i).Alkalinity);//.......................
                            float a=dObj.floatValue();
                            if(!GlobalData.sensordata.get(i).Alkalinity.equals("-1.0"))
                            entries.add(new BarEntry(a,i));
                        }
                        BarDataSet dataset = new BarDataSet(entries, "Alkalinity");//.......................
                        for(int i=0;i<GlobalData.sensordata.size();i++)
                        {
                            if(GlobalData.sensordata.get(i).source.equals("live_sensor_data") && !GlobalData.sensordata.get(i).Alkalinity.equals("-1.0"))
                                labels.add(GlobalData.sensordata.get(i).date+"\n"+GlobalData.sensordata.get(i).time);

                            if(GlobalData.sensordata.get(i).source.equals("Historical")&& !GlobalData.sensordata.get(i).Alkalinity.equals("-1.0"))
                                labels.add(GlobalData.sensordata.get(i).Year+"\n"+Month_s[Integer.parseInt(GlobalData.sensordata.get(i).Month)]);
                        }

                        setContentView(R.layout.layout_graph);
                        BarChart chart = (BarChart) findViewById(R.id.chart);
                        BarData data = new BarData(labels, dataset);
                        chart.setData(data);
                        chart.setDescription("Alkalinity Variation With Time");//.......................
                        chart.setVisibleXRangeMaximum(4);
                        chart.setVisibleXRangeMinimum(2);
                        chart.moveViewToX(-1);
//                        Toast.makeText(cnt, "Datapoints" + GlobalData.sensordata.size(), Toast.LENGTH_SHORT).show();

                        Button close_chart=(Button) findViewById(R.id.close_chart);

                        close_chart.setOnClickListener(new View.OnClickListener() {
                            public void onClick(View v) {

                                show_data_layout();
                            }
                        });

                    }
                });
                P_3b.addView(tv);
            }//end if(s.Do!=-1)


            if(!s.Chloride.isEmpty())//.......................
            {
                TextView tv = new TextView(cnt);

                if(!s.Chloride.equals("-1.0"))
                    tv.setText("Chloride\n" + s.Chloride);
                else
                    tv.setText("Chloride\n" + nodata);

               // tv.setText("Chloride\n" + s.Chloride);//.......................
                tv.setLayoutParams(Param_row);
                tv.setTextSize(20);
                //tv.setBackgroundResource(R.drawable.lightblue);
                tv.setBackgroundColor(Color.parseColor("#DAE5E8"));
                tv.setGravity(Gravity.CENTER);

                tv.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v)
                    {
                        ArrayList<BarEntry> entries = new ArrayList<>();
                        ArrayList<String> labels = new ArrayList<String>();
                        for(int i=0;i<GlobalData.sensordata.size();i++)
                        {
                            Double dObj = new Double(GlobalData.sensordata.get(i).Chloride);//.......................
                            float a=dObj.floatValue();
                            if(!GlobalData.sensordata.get(i).Chloride.equals("-1.0"))
                            entries.add(new BarEntry(a,i));
                        }
                        BarDataSet dataset = new BarDataSet(entries, "Chloride");//.......................
                        for(int i=0;i<GlobalData.sensordata.size();i++)
                        {
                            if(GlobalData.sensordata.get(i).source.equals("live_sensor_data") &&!GlobalData.sensordata.get(i).Chloride.equals("-1.0"))
                                labels.add(GlobalData.sensordata.get(i).date+"\n"+GlobalData.sensordata.get(i).time);

                            if(GlobalData.sensordata.get(i).source.equals("Historical") && !GlobalData.sensordata.get(i).Chloride.equals("-1.0"))
                                labels.add(GlobalData.sensordata.get(i).Year+"\n"+Month_s[Integer.parseInt(GlobalData.sensordata.get(i).Month)]);
                        }

                        setContentView(R.layout.layout_graph);
                        BarChart chart = (BarChart) findViewById(R.id.chart);
                        BarData data = new BarData(labels, dataset);
                        chart.setData(data);
                        chart.setDescription("Chloride Variation With Time");//.......................
                        chart.setVisibleXRangeMaximum(4);
                        chart.setVisibleXRangeMinimum(2);
                        chart.moveViewToX(-1);
                        //Toast.makeText(cnt, "Datapoints" + GlobalData.sensordata.size(), Toast.LENGTH_SHORT).show();

                        Button close_chart=(Button) findViewById(R.id.close_chart);

                        close_chart.setOnClickListener(new View.OnClickListener() {
                            public void onClick(View v) {

                                show_data_layout();
                            }
                        });

                    }
                });
                P_3b.addView(tv);
            }//end if(s.Do!=-1)

            if(!s.Sulphate.isEmpty())//.......................
            {
                TextView tv = new TextView(cnt);
                if(!s.Sulphate.equals("-1.0"))
                    tv.setText("Sulphate\n" + s.Sulphate);
                else
                    tv.setText("Sulphate\n" + nodata);

               // tv.setText("Sulphate\n" + s.Sulphate);//.......................
                tv.setLayoutParams(Param_row);
                tv.setTextSize(20);
                //tv.setBackgroundResource(R.drawable.lightblue);
                tv.setBackgroundColor(Color.parseColor("#DAE5E8"));
                tv.setGravity(Gravity.CENTER);

                tv.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v)
                    {
                        ArrayList<BarEntry> entries = new ArrayList<>();
                        ArrayList<String> labels = new ArrayList<String>();
                        for(int i=0;i<GlobalData.sensordata.size();i++)
                        {
                            Double dObj = new Double(GlobalData.sensordata.get(i).Sulphate);//.......................
                            float a=dObj.floatValue();
                            if(!GlobalData.sensordata.get(i).Sulphate.equals("-1.0"))
                            entries.add(new BarEntry(a,i));
                        }
                        BarDataSet dataset = new BarDataSet(entries, "Sulphate");//.......................
                        for(int i=0;i<GlobalData.sensordata.size();i++)
                        {
                            if(GlobalData.sensordata.get(i).source.equals("live_sensor_data") && !GlobalData.sensordata.get(i).Sulphate.equals("-1.0"))
                                labels.add(GlobalData.sensordata.get(i).date+"\n"+GlobalData.sensordata.get(i).time);

                            if(GlobalData.sensordata.get(i).source.equals("Historical") && !GlobalData.sensordata.get(i).Sulphate.equals("-1.0"))
                                labels.add(GlobalData.sensordata.get(i).Year+"\n"+Month_s[Integer.parseInt(GlobalData.sensordata.get(i).Month)]);
                        }

                        setContentView(R.layout.layout_graph);
                        BarChart chart = (BarChart) findViewById(R.id.chart);
                        BarData data = new BarData(labels, dataset);
                        chart.setData(data);
                        chart.setDescription("Sulphate Variation With Time");//.......................
                        chart.setVisibleXRangeMaximum(4);
                        chart.setVisibleXRangeMinimum(2);
                        chart.moveViewToX(-1);
                       // Toast.makeText(cnt, "Datapoints" + GlobalData.sensordata.size(), Toast.LENGTH_SHORT).show();

                        Button close_chart=(Button) findViewById(R.id.close_chart);

                        close_chart.setOnClickListener(new View.OnClickListener() {
                            public void onClick(View v) {

                                show_data_layout();
                            }
                        });

                    }
                });
                P_3a.addView(tv);
            }//end if(s.Do!=-1)

            if(!s.Cadmium.isEmpty())//.......................
            {
                TextView tv = new TextView(cnt);

                if(!s.Cadmium.equals("-1.0"))
                    tv.setText("Cadmium\n" + s.FS);
                else
                    tv.setText("Cadmium\n" + nodata);


               // tv.setText("Cadmium\n" + s.Cadmium);//.......................
                tv.setLayoutParams(Param_row);
                tv.setTextSize(20);
                //tv.setBackgroundResource(R.drawable.lightblue);
                tv.setBackgroundColor(Color.parseColor("#DAE5E8"));
                tv.setGravity(Gravity.CENTER);

                tv.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v)
                    {
                        ArrayList<BarEntry> entries = new ArrayList<>();
                        ArrayList<String> labels = new ArrayList<String>();
                        for(int i=0;i<GlobalData.sensordata.size();i++)
                        {
                            Double dObj = new Double(GlobalData.sensordata.get(i).Cadmium);//.......................
                            float a=dObj.floatValue();
                            if(!GlobalData.sensordata.get(i).Cadmium.equals("-1.0"))
                            entries.add(new BarEntry(a,i));
                        }
                        BarDataSet dataset = new BarDataSet(entries, "Cadmium");//.......................
                        for(int i=0;i<GlobalData.sensordata.size();i++)
                        {
                            if(GlobalData.sensordata.get(i).source.equals("live_sensor_data") && !GlobalData.sensordata.get(i).Cadmium.equals("-1.0"))
                                labels.add(GlobalData.sensordata.get(i).date+"\n"+GlobalData.sensordata.get(i).time);

                            if(GlobalData.sensordata.get(i).source.equals("Historical") && !GlobalData.sensordata.get(i).Cadmium.equals("-1.0"))
                                labels.add(GlobalData.sensordata.get(i).Year+"\n"+Month_s[Integer.parseInt(GlobalData.sensordata.get(i).Month)]);
                        }

                        setContentView(R.layout.layout_graph);
                        BarChart chart = (BarChart) findViewById(R.id.chart);
                        BarData data = new BarData(labels, dataset);
                        chart.setData(data);
                        chart.setDescription("Cadmium Variation With Time");//.......................
                        chart.setVisibleXRangeMaximum(4);
                        chart.setVisibleXRangeMinimum(2);
                        chart.moveViewToX(-1);
                       // Toast.makeText(cnt, "Datapoints" + GlobalData.sensordata.size(), Toast.LENGTH_SHORT).show();

                        Button close_chart=(Button) findViewById(R.id.close_chart);

                        close_chart.setOnClickListener(new View.OnClickListener() {
                            public void onClick(View v) {

                                show_data_layout();
                            }
                        });

                    }
                });
                P_3a.addView(tv);
            }//end if(s.Do!=-1)



            if(!s.Chromium.isEmpty())//.......................
            {
                TextView tv = new TextView(cnt);

                if(!s.Chromium.equals("-1.0"))
                    tv.setText("Chromium\n" + s.Chromium);
                else
                    tv.setText("Chromium\n" + nodata);


               // tv.setText("Chromium\n" + s.Chromium);//.......................
                tv.setLayoutParams(Param_row);
                tv.setTextSize(20);
                //tv.setBackgroundResource(R.drawable.lightblue);

                if(GlobalData.Purpose.equals("Drinking")||GlobalData.Purpose.equals("Dyeing")||GlobalData.Purpose.equals("Pesticides")||GlobalData.Purpose.equals("Tannery"))
                    tv.setBackgroundColor(Color.parseColor("#FFDAB9"));
                else
                    tv.setBackgroundColor(Color.parseColor("#DAE5E8"));

               // tv.setBackgroundColor(Color.parseColor("#DAE5E8"));
                tv.setGravity(Gravity.CENTER);

                tv.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v)
                    {
                        ArrayList<BarEntry> entries = new ArrayList<>();
                        ArrayList<String> labels = new ArrayList<String>();
                        for(int i=0;i<GlobalData.sensordata.size();i++)
                        {
                            Double dObj = new Double(GlobalData.sensordata.get(i).Chromium);//.......................
                            float a=dObj.floatValue();
                            if(!GlobalData.sensordata.get(i).Chromium.equals("-1.0"))
                            entries.add(new BarEntry(a,i));
                        }
                        BarDataSet dataset = new BarDataSet(entries, "Chromium");//.......................
                        for(int i=0;i<GlobalData.sensordata.size();i++)
                        {
                            if(GlobalData.sensordata.get(i).source.equals("live_sensor_data") && !GlobalData.sensordata.get(i).Chromium.equals("-1.0"))
                                labels.add(GlobalData.sensordata.get(i).date+"\n"+GlobalData.sensordata.get(i).time);

                            if(GlobalData.sensordata.get(i).source.equals("Historical") && !GlobalData.sensordata.get(i).Chromium.equals("-1.0"))
                                labels.add(GlobalData.sensordata.get(i).Year+"\n"+Month_s[Integer.parseInt(GlobalData.sensordata.get(i).Month)]);
                        }

                        setContentView(R.layout.layout_graph);
                        BarChart chart = (BarChart) findViewById(R.id.chart);
                        BarData data = new BarData(labels, dataset);
                        chart.setData(data);
                        chart.setDescription("Chromium Variation With Time");//.......................
                        chart.setVisibleXRangeMaximum(4);
                        chart.setVisibleXRangeMinimum(2);
                        chart.moveViewToX(-1);
                      //  Toast.makeText(cnt, "Datapoints" + GlobalData.sensordata.size(), Toast.LENGTH_SHORT).show();

                        Button close_chart=(Button) findViewById(R.id.close_chart);

                        close_chart.setOnClickListener(new View.OnClickListener() {
                            public void onClick(View v) {

                                show_data_layout();
                            }
                        });

                    }
                });
                P_3a.addView(tv);
            }//end if(s.Do!=-1)


            if(!s.Nickel.isEmpty())//.......................
            {
                TextView tv = new TextView(cnt);

                if(!s.Nickel.equals("-1.0"))
                    tv.setText("Nickel\n" + s.Nickel);
                else
                    tv.setText("Nickel\n" + nodata);


               // tv.setText("Nickel\n" + s.Nickel);//.......................
                tv.setLayoutParams(Param_row);
                tv.setTextSize(20);
                //tv.setBackgroundResource(R.drawable.lightblue);
                tv.setBackgroundColor(Color.parseColor("#DAE5E8"));
                tv.setGravity(Gravity.CENTER);

                tv.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v)
                    {
                        ArrayList<BarEntry> entries = new ArrayList<>();
                        ArrayList<String> labels = new ArrayList<String>();
                        for(int i=0;i<GlobalData.sensordata.size();i++)
                        {
                            Double dObj = new Double(GlobalData.sensordata.get(i).Nickel);//.......................
                            float a=dObj.floatValue();
                            if(!GlobalData.sensordata.get(i).Nickel.equals("-1.0"))
                            entries.add(new BarEntry(a,i));
                        }
                        BarDataSet dataset = new BarDataSet(entries, "Nickel");//.......................
                        for(int i=0;i<GlobalData.sensordata.size();i++)
                        {
                            if(GlobalData.sensordata.get(i).source.equals("live_sensor_data")&&!GlobalData.sensordata.get(i).Nickel.equals("-1.0"))
                                labels.add(GlobalData.sensordata.get(i).date+"\n"+GlobalData.sensordata.get(i).time);

                            if(GlobalData.sensordata.get(i).source.equals("Historical")&&!GlobalData.sensordata.get(i).Nickel.equals("-1.0"))
                                labels.add(GlobalData.sensordata.get(i).Year+"\n"+Month_s[Integer.parseInt(GlobalData.sensordata.get(i).Month)]);
                        }

                        setContentView(R.layout.layout_graph);
                        BarChart chart = (BarChart) findViewById(R.id.chart);
                        BarData data = new BarData(labels, dataset);
                        chart.setData(data);
                        chart.setDescription("Nickel Variation With Time");//.......................
                        chart.setVisibleXRangeMaximum(4);
                        chart.setVisibleXRangeMinimum(2);
                        chart.moveViewToX(-1);
                       // Toast.makeText(cnt, "Datapoints" + GlobalData.sensordata.size(), Toast.LENGTH_SHORT).show();

                        Button close_chart=(Button) findViewById(R.id.close_chart);

                        close_chart.setOnClickListener(new View.OnClickListener() {
                            public void onClick(View v) {

                                show_data_layout();
                            }
                        });

                    }
                });
                P_3a.addView(tv);
            }//end if(s.Do!=-1)


            if(!s.Iron.isEmpty())//.......................
            {
                TextView tv = new TextView(cnt);

                if(!s.Iron.equals("-1.0"))
                    tv.setText("Iron\n" + s.Iron);
                else
                    tv.setText("Iron\n" + nodata);


               // tv.setText("Iron\n" + s.Iron);//.......................
                tv.setLayoutParams(Param_row);
                tv.setTextSize(20);
                //tv.setBackgroundResource(R.drawable.lightblue);
                tv.setBackgroundColor(Color.parseColor("#DAE5E8"));
                tv.setGravity(Gravity.CENTER);

                tv.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v)
                    {
                        ArrayList<BarEntry> entries = new ArrayList<>();
                        ArrayList<String> labels = new ArrayList<String>();
                        for(int i=0;i<GlobalData.sensordata.size();i++)
                        {
                            Double dObj = new Double(GlobalData.sensordata.get(i).Nickel);//.......................
                            float a=dObj.floatValue();
                            if(!GlobalData.sensordata.get(i).Iron.equals("-1.0"))
                            entries.add(new BarEntry(a,i));
                        }
                        BarDataSet dataset = new BarDataSet(entries, "Iron");//.......................
                        for(int i=0;i<GlobalData.sensordata.size();i++)
                        {
                            if(GlobalData.sensordata.get(i).source.equals("live_sensor_data")&&!GlobalData.sensordata.get(i).Iron.equals("-1.0"))
                                labels.add(GlobalData.sensordata.get(i).date+"\n"+GlobalData.sensordata.get(i).time);

                            if(GlobalData.sensordata.get(i).source.equals("Historical")&&!GlobalData.sensordata.get(i).Iron.equals("-1.0"))
                                labels.add(GlobalData.sensordata.get(i).Year+"\n"+Month_s[Integer.parseInt(GlobalData.sensordata.get(i).Month)]);
                        }

                        setContentView(R.layout.layout_graph);
                        BarChart chart = (BarChart) findViewById(R.id.chart);
                        BarData data = new BarData(labels, dataset);
                        chart.setData(data);
                        chart.setDescription("Iron Variation With Time");//.......................
                        chart.setVisibleXRangeMaximum(4);
                        chart.setVisibleXRangeMinimum(2);
                        chart.moveViewToX(-1);
                       // Toast.makeText(cnt, "Datapoints" + GlobalData.sensordata.size(), Toast.LENGTH_SHORT).show();

                        Button close_chart=(Button) findViewById(R.id.close_chart);

                        close_chart.setOnClickListener(new View.OnClickListener() {
                            public void onClick(View v) {

                                show_data_layout();
                            }
                        });

                    }
                });
                P_3a.addView(tv);
            }//end if(s.Do!=-1)



            if(!s.Na.isEmpty())//.......................
            {
                TextView tv = new TextView(cnt);

                if(!s.Na.equals("-1.0"))
                    tv.setText("Na\n" + s.Na);
                else
                    tv.setText("Na\n" + nodata);


                //tv.setText("Na\n" + s.Na);//.......................
                tv.setLayoutParams(Param_row);
                tv.setTextSize(20);
                //tv.setBackgroundResource(R.drawable.lightblue);
                tv.setBackgroundColor(Color.parseColor("#DAE5E8"));
                tv.setGravity(Gravity.CENTER);

                tv.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v)
                    {
                        ArrayList<BarEntry> entries = new ArrayList<>();
                        ArrayList<String> labels = new ArrayList<String>();
                        for(int i=0;i<GlobalData.sensordata.size();i++)
                        {
                            Double dObj = new Double(GlobalData.sensordata.get(i).Na);//.......................
                            float a=dObj.floatValue();
                            if(!GlobalData.sensordata.get(i).Na.equals("-1.0"))
                            entries.add(new BarEntry(a,i));
                        }
                        BarDataSet dataset = new BarDataSet(entries, "Na");//.......................
                        for(int i=0;i<GlobalData.sensordata.size();i++)
                        {
                            if(GlobalData.sensordata.get(i).source.equals("live_sensor_data")&&!GlobalData.sensordata.get(i).Na.equals("-1.0"))
                                labels.add(GlobalData.sensordata.get(i).date+"\n"+GlobalData.sensordata.get(i).time);

                            if(GlobalData.sensordata.get(i).source.equals("Historical")&&!GlobalData.sensordata.get(i).Na.equals("-1.0"))
                                labels.add(GlobalData.sensordata.get(i).Year+"\n"+Month_s[Integer.parseInt(GlobalData.sensordata.get(i).Month)]);
                        }

                        setContentView(R.layout.layout_graph);
                        BarChart chart = (BarChart) findViewById(R.id.chart);
                        BarData data = new BarData(labels, dataset);
                        chart.setData(data);
                        chart.setDescription("Na Variation With Time");//.......................
                        chart.setVisibleXRangeMaximum(4);
                        chart.setVisibleXRangeMinimum(2);
                        chart.moveViewToX(-1);
                       // Toast.makeText(cnt, "Datapoints" + GlobalData.sensordata.size(), Toast.LENGTH_SHORT).show();

                        Button close_chart=(Button) findViewById(R.id.close_chart);

                        close_chart.setOnClickListener(new View.OnClickListener() {
                            public void onClick(View v) {

                                show_data_layout();
                            }
                        });

                    }
                });
                P_3b.addView(tv);
            }//end if(s.Do!=-1)



            if(!s.Nitrate.isEmpty())//.......................
            {
                TextView tv = new TextView(cnt);

                if(!s.Nitrate.equals("-1.0"))
                    tv.setText("Nitrate\n" + s.Nitrate);
                else
                    tv.setText("Nitrate\n" + nodata);

                //tv.setText("Nitrate\n" + s.Nitrate);//.......................
                tv.setLayoutParams(Param_row);
                tv.setTextSize(20);
                //tv.setBackgroundResource(R.drawable.lightblue);
                tv.setBackgroundColor(Color.parseColor("#DAE5E8"));
                tv.setGravity(Gravity.CENTER);

                tv.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v)
                    {
                        ArrayList<BarEntry> entries = new ArrayList<>();
                        ArrayList<String> labels = new ArrayList<String>();
                        for(int i=0;i<GlobalData.sensordata.size();i++)
                        {
                            Double dObj = new Double(GlobalData.sensordata.get(i).Nitrate);//.......................
                            float a=dObj.floatValue();
                            if(!GlobalData.sensordata.get(i).Nitrate.equals("-1.0"))
                            entries.add(new BarEntry(a,i));
                        }
                        BarDataSet dataset = new BarDataSet(entries, "Nitrate");//.......................
                        for(int i=0;i<GlobalData.sensordata.size();i++)
                        {
                            if(GlobalData.sensordata.get(i).source.equals("live_sensor_data")&&!GlobalData.sensordata.get(i).Nitrate.equals("-1.0"))
                                labels.add(GlobalData.sensordata.get(i).date+"\n"+GlobalData.sensordata.get(i).time);

                            if(GlobalData.sensordata.get(i).source.equals("Historical")&&!GlobalData.sensordata.get(i).Nitrate.equals("-1.0"))
                                labels.add(GlobalData.sensordata.get(i).Year+"\n"+Month_s[Integer.parseInt(GlobalData.sensordata.get(i).Month)]);
                        }

                        setContentView(R.layout.layout_graph);
                        BarChart chart = (BarChart) findViewById(R.id.chart);
                        BarData data = new BarData(labels, dataset);
                        chart.setData(data);
                        chart.setDescription("Nitrate Variation With Time");//.......................
                        chart.setVisibleXRangeMaximum(4);
                        chart.setVisibleXRangeMinimum(2);
                        chart.moveViewToX(-1);
                     //   Toast.makeText(cnt, "Datapoints" + GlobalData.sensordata.size(), Toast.LENGTH_SHORT).show();

                        Button close_chart=(Button) findViewById(R.id.close_chart);

                        close_chart.setOnClickListener(new View.OnClickListener() {
                            public void onClick(View v) {

                                show_data_layout();
                            }
                        });

                    }
                });
                P_3a.addView(tv);
            }//end if(s.Do!=-1)



            if(!s.BOD.isEmpty())
            {
                TextView tv = new TextView(cnt);

                if(!s.BOD.equals("-1.0"))
                    tv.setText("BOD\n" + s.BOD);
                else
                    tv.setText("BOD\n" + nodata);

             //   tv.setText("BOD\n" + s.BOD);
                tv.setLayoutParams(Param_row);
                tv.setTextSize(20);
                //tv.setBackgroundResource(R.drawable.lightblue);
                if(GlobalData.Purpose.equals("Distillery")||GlobalData.Purpose.equals("Sugar")||GlobalData.Purpose.equals("Dairy")||GlobalData.Purpose.equals("Slaughter house")||GlobalData.Purpose.equals("Beverage")||GlobalData.Purpose.equals("Pesticides")||GlobalData.Purpose.equals("Pulp and paper")||GlobalData.Purpose.equals("Tannery"))
                    tv.setBackgroundColor(Color.parseColor("#FFDAB9"));
                else
                    tv.setBackgroundColor(Color.parseColor("#DAE5E8"));
                //tv.setBackgroundColor(Color.parseColor("#DAE5E8"));
                tv.setGravity(Gravity.CENTER);

                tv.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v)
                    {
                        ArrayList<BarEntry> entries = new ArrayList<>();
                        ArrayList<String> labels = new ArrayList<String>();
                        for(int i=0;i<GlobalData.sensordata.size();i++)
                        {
                            Double dObj = new Double(GlobalData.sensordata.get(i).BOD);
                            float a=dObj.floatValue();
                            if(!GlobalData.sensordata.get(i).BOD.equals("-1.0"))
                            entries.add(new BarEntry(a,i));
                        }
                        BarDataSet dataset = new BarDataSet(entries, "BOD");
                        for(int i=0;i<GlobalData.sensordata.size();i++)
                        {
                            if(GlobalData.sensordata.get(i).source.equals("live_sensor_data")&&!GlobalData.sensordata.get(i).BOD.equals("-1.0"))
                                labels.add(GlobalData.sensordata.get(i).date+"\n"+GlobalData.sensordata.get(i).time);

                            if(GlobalData.sensordata.get(i).source.equals("Historical")&&!GlobalData.sensordata.get(i).BOD.equals("-1.0"))
                                labels.add(GlobalData.sensordata.get(i).Year+"\n"+Month_s[Integer.parseInt(GlobalData.sensordata.get(i).Month)]);
                        }

                        setContentView(R.layout.layout_graph);
                        BarChart chart = (BarChart) findViewById(R.id.chart);
                        BarData data = new BarData(labels, dataset);
                        chart.setData(data);
                        chart.setDescription("BOD Variation With Time");
                        chart.setVisibleXRangeMaximum(4);
                        chart.setVisibleXRangeMinimum(2);
                        chart.moveViewToX(-1);
                       // Toast.makeText(cnt, "Datapoints" + GlobalData.sensordata.size(), Toast.LENGTH_SHORT).show();

                        Button close_chart=(Button) findViewById(R.id.close_chart);

                        close_chart.setOnClickListener(new View.OnClickListener() {
                            public void onClick(View v) {

                                show_data_layout();
                            }
                        });

                    }
                });
                P_3a.addView(tv);
            }//end if(s.Do!=-1)



            if(!s.COD.isEmpty())
            {
                TextView tv = new TextView(cnt);

                if(!s.COD.equals("-1.0"))
                    tv.setText("COD\n" + s.COD);
                else
                    tv.setText("COD\n" + nodata);


               // tv.setText("COD\n" + s.COD);
                tv.setLayoutParams(Param_row);
                tv.setTextSize(20);
                //tv.setBackgroundResource(R.drawable.lightblue);
                if(GlobalData.Purpose.equals("Distillery")||GlobalData.Purpose.equals("Sugar")||GlobalData.Purpose.equals("Dairy")||GlobalData.Purpose.equals("Slaughter house")||GlobalData.Purpose.equals("Beverage")||GlobalData.Purpose.equals("Dying")||GlobalData.Purpose.equals("Pesticides")||GlobalData.Purpose.equals("Pulp and paper")||GlobalData.Purpose.equals("Tannery"))
                    tv.setBackgroundColor(Color.parseColor("#FFDAB9"));
                else
                    tv.setBackgroundColor(Color.parseColor("#DAE5E8"));

                //tv.setBackgroundColor(Color.parseColor("#DAE5E8"));
                tv.setGravity(Gravity.CENTER);

                tv.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v)
                    {
                        ArrayList<BarEntry> entries = new ArrayList<>();
                        ArrayList<String> labels = new ArrayList<String>();
                        for(int i=0;i<GlobalData.sensordata.size();i++)
                        {
                            Double dObj = new Double(GlobalData.sensordata.get(i).COD);
                            float a=dObj.floatValue();
                            if(!GlobalData.sensordata.get(i).COD.equals("-1.0"))
                            entries.add(new BarEntry(a,i));
                        }
                        BarDataSet dataset = new BarDataSet(entries, "COD");
                        for(int i=0;i<GlobalData.sensordata.size();i++)
                        {
                            if(GlobalData.sensordata.get(i).source.equals("live_sensor_data")&&!GlobalData.sensordata.get(i).COD.equals("-1.0"))
                                labels.add(GlobalData.sensordata.get(i).date+"\n"+GlobalData.sensordata.get(i).time);

                            if(GlobalData.sensordata.get(i).source.equals("Historical")&&!GlobalData.sensordata.get(i).COD.equals("-1.0"))
                                labels.add(GlobalData.sensordata.get(i).Year+"\n"+Month_s[Integer.parseInt(GlobalData.sensordata.get(i).Month)]);
                        }

                        setContentView(R.layout.layout_graph);
                        BarChart chart = (BarChart) findViewById(R.id.chart);
                        BarData data = new BarData(labels, dataset);
                        chart.setData(data);
                        chart.setDescription("COD Variation With Time");
                        chart.setVisibleXRangeMaximum(4);
                        chart.setVisibleXRangeMinimum(2);
                        chart.moveViewToX(-1);
                       // Toast.makeText(cnt, "Datapoints" + GlobalData.sensordata.size(), Toast.LENGTH_SHORT).show();

                        Button close_chart=(Button) findViewById(R.id.close_chart);

                        close_chart.setOnClickListener(new View.OnClickListener() {
                            public void onClick(View v) {

                                show_data_layout();
                            }
                        });

                    }
                });
                P_3a.addView(tv);
            }//end if(s.Do!=-1)



        }//end if(GlobalData.sensordata.size()>0)

        //add in else that there is no data
        else
        {

                TextView tv = new TextView(cnt);
                tv.setText("No Data Yet Available, will update soon");//.......................
                tv.setLayoutParams(Param_row);
                tv.setTextSize(20);
                //tv.setBackgroundResource(R.drawable.lightblue);
                tv.setBackgroundColor(Color.parseColor("#DAE5E8"));
                tv.setGravity(Gravity.CENTER);


                P_4.addView(tv);


        }

        setContentView(P_1);
/*
        ArrayList<BarEntry> entries = new ArrayList<>();
        ArrayList<String> labels = new ArrayList<String>();
        for(int i=0;i<GlobalData.sensordata.size();i++)
        {
            Double dObj = new Double(GlobalData.sensordata.get(i).Do);

            float a=dObj.floatValue();

            entries.add(new BarEntry(a,i));
        }


        BarDataSet dataset = new BarDataSet(entries, "# of Calls");


        for(int i=0;i<GlobalData.sensordata.size();i++)
        {

            labels.add(GlobalData.sensordata.get(i).time);
        }

        BarChart chart = new BarChart(cnt);
        setContentView(chart);

        BarData data = new BarData(labels, dataset);
        chart.setData(data);

        chart.setDescription("Water Quality Parameters :"+GlobalData.sensordata.size());

        Toast.makeText(cnt, "Datapoints" + GlobalData.sensordata.size(), Toast.LENGTH_SHORT).show();
*/

    }


        private class DownloadFilesTask extends AsyncTask<URL, Integer, Long> {
        protected Long doInBackground(URL... urls) {
            //  int count = urls.length;
            long totalSize = 0;
            DefaultHttpClient httpclient = new DefaultHttpClient();

            //////////////////////////////////////////////////////////////
            // loading data of places, thie place which is clicked is set in the global data structures

            HttpPost httppostreq = new HttpPost("http://cdata.mybluemix.net/Send_places_data2");
            try {

                List<NameValuePair> params = new ArrayList<NameValuePair>();
                // params.add(new BasicNameValuePair("key", "value"));
                //if(GlobalData.place_position>=0)
                params.add(new BasicNameValuePair("key", "value"));
                params.add(new BasicNameValuePair("Place_id", "-1"));//we donot store this now
                params.add(new BasicNameValuePair("Lat", GlobalData.current_Lat));
                params.add(new BasicNameValuePair("Lng", GlobalData.current_Lng));
                params.add(new BasicNameValuePair("range","1.0"));//in KM

                httppostreq.setEntity(new UrlEncodedFormEntity(params));
                HttpResponse httpresponse = httpclient.execute(httppostreq);

                InputStream stream=httpresponse.getEntity().getContent();
                BufferedReader reader = new BufferedReader(new InputStreamReader(
                        stream, "UTF-8"), 8);
                StringBuilder sb = new StringBuilder();
                String line = null;
                while ((line = reader.readLine()) != null) {
                    sb.append(line + "\n");
                }
                String response2 = sb.toString();
                stream.close();
                //
                //Toast.makeText(cnt, stream.toString(), Toast.LENGTH_SHORT).show();
                Log.d("cloud server", "stream from server" + response2);

                //places are in response string
                try {
                    JSONArray jsonArray = new JSONArray(response2);

                    //clearing already read places in the memory
                    if(GlobalData.Datapoint>0)
                    {
                        GlobalData.Datapoint=0;
                        GlobalData.sensordata.clear();
                    }


                    for (int i = 0; i < jsonArray.length(); i++) {
                        JSONObject jo_inside = jsonArray.getJSONObject(i);
                        if(jo_inside.has("Place_name"))
                            Log.d("Details-data->", jo_inside.getString("Place_name"));

                        SensorData s=new SensorData();

                        if(jo_inside.has("source"))
                            s.source=jo_inside.getString("source");

                        if(s.source.equals("Historical"))
                        {
                            if (jo_inside.has("Place_id"))
                                s.Place_id = jo_inside.getString("Place_id");
                            if (jo_inside.has("Place_name"))
                                s.Place_name = jo_inside.getString("Place_name");

                            if(jo_inside.has("lat"))
                                s.lat = jo_inside.getDouble("lat");//compatibility
                            if(jo_inside.has("lng"))
                                s.lng=jo_inside.getDouble("lng");//compatibility

                            if (jo_inside.has("Lat"))
                                s.Lat = jo_inside.getString("Lat");//compatibility
                            if (jo_inside.has("Lng"))
                                s.Lng = jo_inside.getString("Lng");//compatibility
                            if (jo_inside.has("Year"))
                                s.Year = jo_inside.getString("Year");
                            if (jo_inside.has("Month"))
                                s.Month = jo_inside.getString("Month");
                            if (jo_inside.has("Air_Temperature"))
                                s.Air_Temperature = jo_inside.getString("Air_Temperature");
                            if (jo_inside.has("Water_Temperature"))
                                s.Water_Temperature = jo_inside.getString("Water_Temperature");
                            if (jo_inside.has("DO"))
                                s.DO = jo_inside.getString("DO");
                            if (jo_inside.has("BOD"))
                                s.BOD = jo_inside.getString("BOD");
                            if (jo_inside.has("COD"))
                                s.COD = jo_inside.getString("COD");
                            if (jo_inside.has("pH"))
                                s.pH = jo_inside.getString("pH");
                            if (jo_inside.has("Turbidity"))
                                s.Turbidity = jo_inside.getString("Turbidity");
                            if (jo_inside.has("Conductivity"))
                                s.Conductivity = jo_inside.getString("Conductivity");
                            if (jo_inside.has("TC"))
                                s.TC = jo_inside.getString("TC");
                            if (jo_inside.has("FC"))
                                s.FC = jo_inside.getString("FC");
                            if (jo_inside.has("FS"))
                                s.FS = jo_inside.getString("FS");
                            if (jo_inside.has("Velocity"))
                                s.Velocity = jo_inside.getString("Velocity");
                            if (jo_inside.has("Hardness"))
                                s.Hardness = jo_inside.getString("Hardness");
                            if (jo_inside.has("Alkalinity"))
                                s.Alkalinity = jo_inside.getString("Alkalinity");
                            if (jo_inside.has("Chloride"))
                                s.Chloride = jo_inside.getString("Chloride");
                            if (jo_inside.has("Cadmium"))
                                s.Cadmium = jo_inside.getString("Cadmium");
                            if (jo_inside.has("Chromium"))
                                s.Chromium = jo_inside.getString("Chromium");
                            if (jo_inside.has("Sulphate"))
                                s.Sulphate = jo_inside.getString("Sulphate");
                            if (jo_inside.has("Nickel"))
                                s.Nickel = jo_inside.getString("Nickel");
                            if (jo_inside.has("Iron"))
                                s.Iron = jo_inside.getString("Iron");
                            if (jo_inside.has("Na"))
                                s.Na = jo_inside.getString("Na");


                            GlobalData.sensordata.add(s);
                            GlobalData.Datapoint++;

                        }//end if(s.source.equal("historical")

                        else if(s.source.equals("live_sensor_data"))
                        {
                            if(jo_inside.has("lat"))
                                s.lat = jo_inside.getDouble("lat");
                            if(jo_inside.has("lng"))
                                s.lng=jo_inside.getDouble("lng");
                            //if(jo_inside.has("Do"))
                             //   s.Do=jo_inside.getDouble("Do");
                            if(jo_inside.has("time"))
                                s.time = jo_inside.getString("time");
                            if(jo_inside.has("date"))
                                s.date=jo_inside.getString("date");

                            {//assigning first dummy one's,
                                //some of the parameters will be later modified correctly

                                if (jo_inside.has("Air_Temperature"))
                                    s.Air_Temperature = jo_inside.getString("Air_Temperature");
                                if (jo_inside.has("Water_Temperature"))
                                    s.Water_Temperature = jo_inside.getString("Water_Temperature");
                                if (jo_inside.has("DO"))
                                    s.DO = jo_inside.getString("DO");
                                if (jo_inside.has("BOD"))
                                    s.BOD = jo_inside.getString("BOD");
                                if (jo_inside.has("COD"))
                                    s.COD = jo_inside.getString("COD");
                                if (jo_inside.has("pH"))
                                    s.pH = jo_inside.getString("pH");
                                if (jo_inside.has("Turbidity"))
                                    s.Turbidity = jo_inside.getString("Turbidity");
                                if (jo_inside.has("Conductivity"))
                                    s.Conductivity = jo_inside.getString("Conductivity");
                                if (jo_inside.has("TC"))
                                    s.TC = jo_inside.getString("TC");
                                if (jo_inside.has("FC"))
                                    s.FC = jo_inside.getString("FC");
                                if (jo_inside.has("FS"))
                                    s.FS = jo_inside.getString("FS");
                                if (jo_inside.has("Velocity"))
                                    s.Velocity = jo_inside.getString("Velocity");
                                if (jo_inside.has("Hardness"))
                                    s.Hardness = jo_inside.getString("Hardness");
                                if (jo_inside.has("Alkalinity"))
                                    s.Alkalinity = jo_inside.getString("Alkalinity");
                                if (jo_inside.has("Chloride"))
                                    s.Chloride = jo_inside.getString("Chloride");
                                if (jo_inside.has("Cadmium"))
                                    s.Cadmium = jo_inside.getString("Cadmium");
                                if (jo_inside.has("Chromium"))
                                    s.Chromium = jo_inside.getString("Chromium");
                                if (jo_inside.has("Sulphate"))
                                    s.Sulphate = jo_inside.getString("Sulphate");
                                if (jo_inside.has("Nickel"))
                                    s.Nickel = jo_inside.getString("Nickel");
                                if (jo_inside.has("Iron"))
                                    s.Iron = jo_inside.getString("Iron");
                                if (jo_inside.has("Na"))
                                    s.Na = jo_inside.getString("Na");

                            }//end assigning first dummy one's,


                            if(jo_inside.has("ph"))
                                s.pH=jo_inside.getString("ph");
                               // s.ph=jo_inside.getDouble("ph");

                            if(jo_inside.has("temp"))
                                s.Water_Temperature=jo_inside.getString("temp");
                                //s.temp=jo_inside.getDouble("temp");

                            if(jo_inside.has("orpmv"))//oxygen reduction potential
                                s.orpmv=jo_inside.getDouble("orpmv");

                            if(jo_inside.has("ecscm"))
                                s.Conductivity=jo_inside.getString("ecscm");
                                //s.ecscm=jo_inside.getDouble("ecscm");

                            if(jo_inside.has("ecabsscm"))
                                s.ecabsscm=jo_inside.getDouble("ecabsscm");

                            if(jo_inside.has("resohmcm"))
                                s.resohmcm=jo_inside.getDouble("resohmcm");

                            if(jo_inside.has("tdsppm"))
                              s.TDS =jo_inside.getString("tdsppm");
                                //s.tdsppm=jo_inside.getDouble("tdsppm");

                            if(jo_inside.has("salpsu"))
                                s.salpsu=jo_inside.getDouble("salpsu");

                            if(jo_inside.has("sigmat"))
                                s.sigmat=jo_inside.getDouble("sigmat");

                            if(jo_inside.has("presspsi"))
                                s.presspsi=jo_inside.getDouble("presspsi");

                            //if(jo_inside.has("Do"))
                             //   s.Do=jo_inside.getDouble("Do");

                            if(jo_inside.has("doppm"))
                                s.DO=jo_inside.getString("doppm");
                                //s.doppm=jo_inside.getDouble("doppm");

                            if(jo_inside.has("domgl"))
                               // s.DO=jo_inside.getString("domgl");
                                s.domgl=jo_inside.getDouble("domgl");

                            if(jo_inside.has("turbfnu"))
                                s.Turbidity=jo_inside.getString("turbfnu");
                                //s.turbfnu=jo_inside.getDouble("turbfnu");

                            if(jo_inside.has("ppmni"))
                                s.Nitrate=jo_inside.getString("ppmni");
                                //s.ppmni=jo_inside.getDouble("ppmni");

                            GlobalData.sensordata.add(s);
                            GlobalData.Datapoint++;
                        }//end else if(s.source.equals("live_sensor_data"))



                    }

                } catch (JSONException e) {
                    e.printStackTrace();
                }


            } catch (IOException e) {
                e.printStackTrace();
            }


            return totalSize;
        }//end function

        protected void onProgressUpdate(Integer... progress) {
            //setProgressPercent(progress[0]);
        }

        protected void onPostExecute(Long result) {
            // showDialog("Downloaded " + result + " bytes");

            // Intent intent = new Intent(cnt, List_places.class);
            //startActivity(intent);
            show_data_layout();

        }//end onpost
    }



    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_places_data2, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }
}
