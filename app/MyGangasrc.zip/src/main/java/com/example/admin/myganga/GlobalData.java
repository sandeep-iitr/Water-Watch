package com.example.admin.myganga;

import java.util.ArrayList;

/**
 * Created by admin on 5/18/2015.
 */
public class GlobalData {

    public static ArrayList<Places> place = new ArrayList<Places>();

    public static ArrayList<SensorData> sensordata = new ArrayList<SensorData>();

    public static ArrayList<Data_IBM_sensors> IBMsensordata = new ArrayList<Data_IBM_sensors>();

    public static int numPlaces=0;

    public static int Datapoint=0;

    public static int month=1;

    public static int Year=-1;

    public static String current_marker="";//name of the current selected place, used in to show data
   // public static int place_position=-1;//position of current selected place in the Places arraylist,used in to show data
    public static String current_Lat;//lat of current selected place
    public static String current_Lng;//lng of current selected place


    public static int general_limit=0;//default 0, means no limit has been read yet
    public static Limits_general lg;

    public static String Purpose="All";
}

